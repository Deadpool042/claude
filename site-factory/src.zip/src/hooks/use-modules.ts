"use client";

import { useCallback, useState, type Dispatch, type SetStateAction } from "react";
import { MODULE_CATALOG, type ModuleTierSelection } from "@/lib/qualification";

// ── Types ──────────────────────────────────────────────────────────

export interface UseModulesReturn {
  selectedModules: Set<string>;
  tierSelections: Record<string, ModuleTierSelection>;
  setTierSelections: Dispatch<SetStateAction<Record<string, ModuleTierSelection>>>;
  toggleModule: (id: string) => void;
  clearModules: () => void;
}

// ── Hook ───────────────────────────────────────────────────────────

export function useModules(initialModuleIds: string[] = []): UseModulesReturn {
  const [selectedModules, setSelectedModules] = useState<Set<string>>(
    () => new Set(initialModuleIds),
  );

  const [tierSelections, setTierSelections] = useState<
    Record<string, ModuleTierSelection>
  >(() => {
    const initial: Record<string, ModuleTierSelection> = {};
    for (const id of initialModuleIds) {
      const mod = MODULE_CATALOG.find((m) => m.id === id);
      if (mod?.setupTiers || mod?.subscriptionTiers) {
        const sel: ModuleTierSelection = {};
        if (mod.setupTiers?.[0]) sel.setupTierId = mod.setupTiers[0].id;
        if (mod.subscriptionTiers?.[0]) sel.subTierId = mod.subscriptionTiers[0].id;
        initial[id] = sel;
      }
    }
    return initial;
  });

  const toggleModule = useCallback((id: string) => {
    const mod = MODULE_CATALOG.find((m) => m.id === id);
    setSelectedModules((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        setTierSelections((ts) => {
          const { [id]: _, ...rest } = ts;
          return rest;
        });
      } else {
        next.add(id);
        if (mod?.setupTiers || mod?.subscriptionTiers) {
          setTierSelections((ts) => {
            const sel: ModuleTierSelection = {};
            if (mod.setupTiers?.[0]) sel.setupTierId = mod.setupTiers[0].id;
            if (mod.subscriptionTiers?.[0]) sel.subTierId = mod.subscriptionTiers[0].id;
            return { ...ts, [id]: sel };
          });
        }
      }
      return next;
    });
  }, []);

  const clearModules = useCallback(() => {
    setSelectedModules(new Set());
    setTierSelections({});
  }, []);

  return {
    selectedModules,
    tierSelections,
    setTierSelections,
    toggleModule,
    clearModules,
  };
}
