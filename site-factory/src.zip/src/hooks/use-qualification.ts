"use client";

import { useMemo } from "react";
import {
  qualifyProject,
  type ProjectType,
  type TechStack,
  type BillingMode,
  type DeployTarget,
  type ModuleTierSelection,
  type QualificationResult,
} from "@/lib/qualification";

// ── Types ──────────────────────────────────────────────────────────

export interface UseQualificationParams {
  projectType: ProjectType | null;
  techStack: TechStack;
  selectedModules: Set<string>;
  billingMode: BillingMode;
  deployTarget: DeployTarget;
  wpHeadless: boolean;
  tierSelections: Record<string, ModuleTierSelection>;
}

// ── Hook ───────────────────────────────────────────────────────────

export function useQualification(
  params: UseQualificationParams,
): QualificationResult | null {
  const {
    projectType,
    techStack,
    selectedModules,
    billingMode,
    deployTarget,
    wpHeadless,
    tierSelections,
  } = params;

  return useMemo(() => {
    if (!projectType) return null;
    return qualifyProject({
      projectType,
      techStack,
      selectedModuleIds: Array.from(selectedModules),
      billingMode,
      deployTarget,
      wpHeadless,
      tierSelections,
    });
  }, [
    projectType,
    techStack,
    selectedModules,
    billingMode,
    deployTarget,
    wpHeadless,
    tierSelections,
  ]);
}
