"use client";

import {
  CATEGORY_COLORS,
  CATEGORY_SHORT,
  resolveModulePrice,
  resolveModuleMonthly,
  type ModuleDef,
  type TechStack,
  type Category,
  type ModuleTierSelection,
} from "@/lib/qualification";
import { MODULE_ICONS, formatEur } from "@/lib/qualification-ui";
import { TierSelector } from "./tier-selector";
import { Badge } from "@/components/ui/badge";
import { Check, Wrench } from "lucide-react";

// ── Props ──────────────────────────────────────────────────────────

interface ModuleCardProps {
  mod: ModuleDef;
  isSelected: boolean;
  onToggle: () => void;
  tierSel?: ModuleTierSelection;
  onTierChange: (modId: string, tierSel: ModuleTierSelection) => void;
  techStack: TechStack;
  /** Catégorie initiale (avant modules) — sert à afficher l'alerte "requalifie ↑" */
  initialCategory?: Category;
}

// ── Component ──────────────────────────────────────────────────────

export function ModuleCard({
  mod,
  isSelected,
  onToggle,
  tierSel,
  onTierChange,
  techStack,
  initialCategory,
}: ModuleCardProps) {
  const ModIcon = MODULE_ICONS[mod.icon] ?? Wrench;
  const hasTiers = !!(mod.setupTiers || mod.subscriptionTiers);

  // Résoudre le requalifiesTo en tenant compte du tier sélectionné
  const effectiveRequalTo =
    hasTiers && tierSel?.setupTierId
      ? (mod.setupTiers?.find((t) => t.id === tierSel.setupTierId)
          ?.requalifiesTo ?? mod.requalifiesTo)
      : mod.requalifiesTo;

  const catOrder = ["CAT1", "CAT2", "CAT3", "CAT4"];
  const wouldRequalify =
    effectiveRequalTo &&
    initialCategory &&
    catOrder.indexOf(effectiveRequalTo) > catOrder.indexOf(initialCategory);

  const resolved = resolveModulePrice(mod, techStack, tierSel);
  const monthly = resolveModuleMonthly(mod, tierSel);

  return (
    <div className="flex flex-col gap-0">
      <button
        type="button"
        onClick={onToggle}
        className={`group relative flex items-start gap-3 rounded-lg border-2 p-3 text-left transition-all ${
          isSelected
            ? `border-primary bg-primary/5 shadow-sm ${hasTiers ? "rounded-b-none" : ""}`
            : "border-border hover:border-muted-foreground/30"
        }`}
      >
        <div
          className={`mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg transition-colors ${
            isSelected
              ? "bg-primary text-primary-foreground"
              : "bg-muted text-muted-foreground"
          }`}
        >
          <ModIcon className="size-4" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">{mod.name}</span>
            {mod.isStructurant && (
              <Badge variant="outline" className="text-[9px] px-1 py-0">
                structurant
              </Badge>
            )}
          </div>

          <p className="mt-0.5 text-xs text-muted-foreground line-clamp-1">
            {mod.description}
          </p>

          {techStack === "WORDPRESS" && mod.wpNote && (
            <p className="text-[10px] text-blue-500/70 dark:text-blue-400/70">
              {mod.wpNote}
            </p>
          )}

          <div className="mt-1 flex flex-wrap items-center gap-2 text-[10px] text-muted-foreground">
            <span>
              {formatEur(resolved.setup)}
              {resolved.setupMax ? `–${formatEur(resolved.setupMax)}` : ""}
              {mod.jsMultiplier !== 1 && techStack !== "WORDPRESS" ? (
                <span className="ml-1 opacity-60">
                  (WP: {formatEur(mod.priceSetup)})
                </span>
              ) : null}
            </span>

            {monthly > 0 && (
              <span className="text-amber-600 dark:text-amber-400">
                + {String(monthly)} €/mois
              </span>
            )}

            {effectiveRequalTo && (
              <Badge
                variant="outline"
                className={`text-[9px] px-1 py-0 ${CATEGORY_COLORS[effectiveRequalTo]}`}
              >
                → {CATEGORY_SHORT[effectiveRequalTo]}
              </Badge>
            )}

            {wouldRequalify && !isSelected && (
              <Badge
                variant="outline"
                className="text-[9px] px-1 py-0 text-amber-600 border-amber-300 dark:text-amber-400 dark:border-amber-700"
              >
                requalifie ↑
              </Badge>
            )}
          </div>
        </div>

        {isSelected && (
          <div className="absolute right-2 top-2 flex size-5 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <Check className="size-3" />
          </div>
        )}
      </button>

      {/* Tier selectors — visible quand le module est sélectionné et possède des tiers */}
      {isSelected && hasTiers && (
        <TierSelector
          mod={mod}
          tierSel={tierSel}
          onTierChange={(newSel) => { onTierChange(mod.id, newSel); }}
        />
      )}
    </div>
  );
}
