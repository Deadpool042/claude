// src/app/api/quotes/[projectId]/route.ts
import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";

const modulesJsonSchema = z.array(z.string()).catch([]); // modules stockés en JSON string

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ projectId: string }> },
) {
  const { projectId } = await params;

  const project = await prisma.project.findUnique({
    where: { id: projectId },
    select: {
      id: true,
      name: true,
      slug: true,
      type: true,
      status: true,
      techStack: true,
      deployTarget: true,
      domain: true,
      client: {
        select: {
          name: true,
          firstName: true,
          lastName: true,
          email: true,
          phone: true,
        },
      },
      qualification: {
        select: {
          modules: true,
          maintenanceLevel: true,
          estimatedBudget: true,
        },
      },
    },
  });

  if (!project) {
    return NextResponse.json({ error: "Projet introuvable" }, { status: 404 });
  }

  const modules = modulesJsonSchema.parse(
    project.qualification?.modules ? safeJsonParse(project.qualification.modules) : [],
  );

  return NextResponse.json({
    project: {
      id: project.id,
      name: project.name,
      slug: project.slug,
      type: project.type,
      status: project.status,
      techStack: project.techStack,
      deployTarget: project.deployTarget,
      domain: project.domain,
    },
    client: project.client,
    qualification: {
      modules,
      maintenanceLevel: project.qualification?.maintenanceLevel ?? null,
      estimatedBudget: project.qualification?.estimatedBudget ?? null,
    },
  });
}

function safeJsonParse(input: string): unknown {
  try {
    return JSON.parse(input) as unknown;
  } catch {
    return [];
  }
}