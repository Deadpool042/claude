import { NextResponse } from "next/server";
import { exec } from "node:child_process";
import { promisify } from "node:util";
import { resolve } from "node:path";
import { access } from "node:fs/promises";
import { prisma } from "@/lib/db";

import {
  buildExpectedServices,
  buildEnabledServiceIds,
  isOptionalServiceIdString,
  isDeployTargetLiteral,
  isStackLiteral,
  isDbTypeLiteral,
  isFrontendStackLiteral,
  type DeployTargetLiteral,
  type StackLiteral,
  type OptionalServiceId,
  type PersistedProjectServiceRow,
  type ExpectedService,
} from "@/lib/service-catalog";

import { DeployTarget } from "@/generated/prisma/client";

const execAsync = promisify(exec);
const CONFIGS_ROOT = resolve(process.cwd(), "..", "configs");

interface DockerPsService {
  Name: string;
  Service: string;
  State: string;
  Status: string;
  Publishers?: { PublishedPort: number; TargetPort: number; Protocol: string }[];
}

interface ProjectInfo {
  dir: string;
  slug: string;
  techStack: StackLiteral | null;
  deployTarget: DeployTargetLiteral;
  enabledIds: Set<OptionalServiceId>;
  dbType: "POSTGRESQL" | "MARIADB" | null;
  wpHeadless: boolean;
  frontendStack: "NEXTJS" | "NUXT" | "ASTRO" | null;
}



async function getProjectInfo(projectId: string): Promise<ProjectInfo | null> {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    select: {
      slug: true,
      techStack: true,
      deployTarget: true,
      client: { select: { slug: true } },
      services: { select: { serviceId: true, enabled: true } },
      database: { select: { dbType: true } },
      wpConfig: { select: { wpHeadless: true, frontendStack: true } },
    },
  });

  if (!project) return null;

  const techStack = isStackLiteral(project.techStack) ? project.techStack : null;

  const deployTarget: DeployTargetLiteral = isDeployTargetLiteral(project.deployTarget)
    ? project.deployTarget
    : "DOCKER";

  // ✅ Narrow Prisma rows -> PersistedProjectServiceRow[]
  const persistedRows: PersistedProjectServiceRow[] = project.services
    .filter(
      (s): s is { serviceId: OptionalServiceId; enabled: boolean } =>
        isOptionalServiceIdString(s.serviceId),
    )
    .map((s) => ({ serviceId: s.serviceId, enabled: s.enabled }));

  const enabledIds = buildEnabledServiceIds(persistedRows);

  const dbType = isDbTypeLiteral(project.database?.dbType) ? project.database!.dbType : null;

  const frontendStack = isFrontendStackLiteral(project.wpConfig?.frontendStack)
    ? project.wpConfig!.frontendStack
    : null;

  return {
    dir: resolve(CONFIGS_ROOT, project.client.slug, project.slug),
    slug: project.slug,
    techStack,
    deployTarget,
    enabledIds,
    dbType,
    wpHeadless: project.wpConfig?.wpHeadless ?? false,
    frontendStack,
  };
}

/** GET — list all expected services merged with Docker state */
export async function GET(
  req: Request,
  { params }: { params: Promise<{ projectId: string }> },
): Promise<NextResponse> {
  const { projectId } = await params;

  const info = await getProjectInfo(projectId);
  if (!info) {
    return NextResponse.json({ error: "Projet introuvable" }, { status: 404 });
  }

  const url = new URL(req.url);
  const mode = url.searchParams.get("mode") === "prod-like" ? "prod-like" : ("dev" as const);
  const composeFile = mode === "prod-like" ? "docker-compose.prod-like.yml" : "docker-compose.local.yml";

  const composePath = resolve(info.dir, composeFile);
  let composeExists = false;

  try {
    await access(composePath);
    composeExists = true;
  } catch {
    // file doesn't exist
  }

  const services: ExpectedService[] = buildExpectedServices(
    info.slug,
    info.techStack,
    info.enabledIds,
    info.dbType,
    info.wpHeadless,
    info.frontendStack,
    mode,
    info.deployTarget,
  );

  if (composeExists) {
    try {
      const { stdout } = await execAsync(`docker compose -f ${composeFile} ps -a --format json`, {
        cwd: info.dir,
      });

      const lines = stdout.trim().split("\n").filter(Boolean);
      const dockerState = new Map<string, DockerPsService>();

      for (const line of lines) {
        const svc = JSON.parse(line) as DockerPsService;
        dockerState.set(svc.Service, svc);
      }

      for (const svc of services) {
        const docker = dockerState.get(svc.service);
        if (docker) {
          svc.state = docker.State;
          svc.status = docker.Status;
          svc.ports = (docker.Publishers ?? [])
            .filter((p) => p.PublishedPort > 0)
            .map((p) => `${String(p.PublishedPort)}:${String(p.TargetPort)}`);
          dockerState.delete(svc.service);
        }
      }

      for (const [, docker] of dockerState) {
        services.push({
          service: docker.Service,
          label: docker.Service,
          state: docker.State,
          status: docker.Status,
          ports: (docker.Publishers ?? [])
            .filter((p) => p.PublishedPort > 0)
            .map((p) => `${String(p.PublishedPort)}:${String(p.TargetPort)}`),
          description: "Service non configuré (résidu)",
          expected: false,
        });
      }
    } catch {
      // docker compose ps can fail when nothing exists yet
    }
  }

  return NextResponse.json({ services, projectSlug: info.slug, composeExists });
}

/** POST — perform actions (up, stop, restart, down, logs) */
export async function POST(
  req: Request,
  { params }: { params: Promise<{ projectId: string }> },
): Promise<NextResponse> {
  const { projectId } = await params;

  const info = await getProjectInfo(projectId);
  if (!info) {
    return NextResponse.json({ error: "Projet introuvable" }, { status: 404 });
  }

  const body = (await req.json()) as { action: string; service?: string };
  const { action, service } = body;

  const validActions = ["up", "stop", "restart", "down", "logs", "generate", "down-clean", "prune"] as const;
  if (!validActions.includes(action as (typeof validActions)[number])) {
    return NextResponse.json(
      { error: `Action invalide. Valeurs possibles : ${validActions.join(", ")}` },
      { status: 400 },
    );
  }

  try {
    if (action === "generate") {
      const { generateComposeFragment } = await import("@/lib/generators/compose");

      const project = await prisma.project.findUnique({
        where: { id: projectId },
        include: {
          client: true,
          runtime: true,
          database: true,
          wpConfig: true,
          nextConfig: true,
          services: true,
        },
      });

      if (!project) return NextResponse.json({ error: "Projet introuvable" }, { status: 404 });

      const port = project.runtime?.port;
      if (port == null) return NextResponse.json({ error: "Port non configuré" }, { status: 400 });

      // ✅ Narrow enabled services -> Set<OptionalServiceId>
      const enabledServiceIds = new Set<OptionalServiceId>(
        project.services
          .filter((s) => s.enabled)
          .map((s) => s.serviceId)
          .filter((id): id is OptionalServiceId => isOptionalServiceIdString(id)),
      );

      // Project deployTarget is already Prisma enum; but Compose expects that enum, so pass it directly.
      // If you want to use the literal conversion, use info.deployTarget.
      const deployTargetEnum = project.deployTarget ?? DeployTarget.DOCKER;

      await generateComposeFragment({
        projectSlug: project.slug,
        clientSlug: project.client.slug,
        port,
        domain: project.domain,
        type: project.type,
        techStack: project.techStack,
        deployTarget: deployTargetEnum,
        devMode: project.devMode, // ✅ required by ComposeProjectInput
        enabledServiceIds,
        database: project.database
          ? {
              dbType: project.database.dbType,
              dbVersion: project.database.dbVersion,
              dbName: project.database.dbName,
              dbUser: project.database.dbUser,
              dbPassword: project.database.dbPassword,
            }
          : null,
        wpConfig: project.wpConfig
          ? {
              phpVersion: project.wpConfig.phpVersion,
              wpHeadless: project.wpConfig.wpHeadless,
              frontendStack: project.wpConfig.frontendStack,
              wpSiteTitle: project.wpConfig.wpSiteTitle,
              wpAdminUser: project.wpConfig.wpAdminUser,
              wpAdminPassword: project.wpConfig.wpAdminPassword,
              wpAdminEmail: project.wpConfig.wpAdminEmail,
              wpPermalinkStructure: project.wpConfig.wpPermalinkStructure,
              wpDefaultPages: project.wpConfig.wpDefaultPages,
              wpPlugins: project.wpConfig.wpPlugins,
              wpTheme: project.wpConfig.wpTheme,
            }
          : null,
        nextConfig: project.nextConfig
          ? {
              nodeVersion: project.nextConfig.nodeVersion,
              envVarsJson: project.nextConfig.envVarsJson,
            }
          : null,
      });

      return NextResponse.json({
        success: true,
        message: "docker-compose.local.yml et docker-compose.prod-like.yml générés",
      });
    }

    if (action === "down-clean") {
      const { stdout, stderr } = await execAsync(
        "docker compose -f docker-compose.local.yml down -v --rmi all --remove-orphans",
        { cwd: info.dir, timeout: 120_000 },
      );
      return NextResponse.json({
        success: true,
        action: "down-clean",
        message: "Conteneurs, volumes et images supprimés",
        output: stdout || stderr,
      });
    }

    if (action === "prune") {
      const results: string[] = [];

      try {
        const { stdout } = await execAsync("docker compose -f docker-compose.local.yml rm -f -s -v", {
          cwd: info.dir,
          timeout: 30_000,
        });
        if (stdout.trim()) results.push(stdout.trim());
      } catch {
        // ignore
      }

      try {
        const { stdout } = await execAsync("docker image prune -f", { timeout: 30_000 });
        if (stdout.trim()) results.push(stdout.trim());
      } catch {
        // ignore
      }

      try {
        const { stdout } = await execAsync("docker volume prune -f", { timeout: 30_000 });
        if (stdout.trim()) results.push(stdout.trim());
      } catch {
        // ignore
      }

      return NextResponse.json({
        success: true,
        action: "prune",
        message: "Ressources Docker inutilisées nettoyées",
        output: results.join("\n"),
      });
    }

    const svcArg = service ?? "";

    if (action === "logs") {
      const { stdout, stderr } = await execAsync(
        `docker compose -f docker-compose.local.yml logs ${svcArg} --tail 100 --no-color`,
        { cwd: info.dir, timeout: 10_000 },
      );
      return NextResponse.json({ logs: stdout || stderr });
    }

    const DC = "docker compose -f docker-compose.local.yml";
    const commands: Record<string, string> = {
      up: `${DC} up -d ${svcArg}`,
      stop: `${DC} stop ${svcArg}`,
      restart: `${DC} restart ${svcArg}`,
      down: `${DC} down`,
    };

    const command = commands[action];
    if (!command) return NextResponse.json({ error: "Action inconnue" }, { status: 400 });

    const { stdout, stderr } = await execAsync(command, { cwd: info.dir, timeout: 60_000 });

    return NextResponse.json({
      success: true,
      action,
      service: service ?? "all",
      output: stdout || stderr,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Erreur inconnue";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}