import { resolve } from "node:path";
import { spawn } from "node:child_process";
import { prisma } from "@/lib/db";

const CONFIGS_ROOT = resolve(process.cwd(), "..", "configs");

export const dynamic = "force-dynamic";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ projectId: string }> },
): Promise<Response> {
  const { projectId } = await params;
  const searchParams = new URL(req.url).searchParams;
  const service = searchParams.get("service") ?? undefined;

  const project = await prisma.project.findUnique({
    where: { id: projectId },
    select: {
      slug: true,
      client: { select: { slug: true } },
    },
  });

  if (!project) {
    return new Response("Projet introuvable", { status: 404 });
  }

  const { slug: clientSlug } = project.client as { slug: string };
  const dir = resolve(CONFIGS_ROOT, clientSlug, project.slug);

  const args = ["compose", "logs", "--follow", "--tail", "80", "--no-color"];
  if (service) args.push(service);

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      const proc = spawn("docker", args, { cwd: dir, stdio: ["ignore", "pipe", "pipe"] });

      function send(data: string) {
        const lines = data.split("\n");
        for (const line of lines) {
          if (line.trim()) {
            controller.enqueue(encoder.encode(`data: ${JSON.stringify(line)}\n\n`));
          }
        }
      }

      proc.stdout.on("data", (chunk: Buffer) => {
        send(chunk.toString());
      });

      proc.stderr.on("data", (chunk: Buffer) => {
        send(chunk.toString());
      });

      proc.on("error", () => {
        controller.enqueue(encoder.encode(`data: ${JSON.stringify("[Erreur de connexion aux logs Docker]")}\n\n`));
        controller.close();
      });

      proc.on("close", () => {
        try { controller.close(); } catch { /* already closed */ }
      });

      // Cleanup on client disconnect
      req.signal.addEventListener("abort", () => {
        proc.kill("SIGTERM");
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
