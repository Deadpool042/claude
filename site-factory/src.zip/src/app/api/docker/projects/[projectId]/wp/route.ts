import { NextResponse } from "next/server";
import { getWpProjectRef } from "@/lib/wp/infra/wp-project-repo";
import { WpService, createWpServiceDeps } from "@/lib/wp/wp-service";
import { wpActionSchema } from "@/lib/wp/wp-validators";

const service = new WpService(createWpServiceDeps());

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ projectId: string }> },
): Promise<NextResponse> {
  const { projectId } = await params;
  const ref = await getWpProjectRef(projectId);

  if (!ref) {
    return NextResponse.json({ error: "Projet WordPress introuvable" }, { status: 404 });
  }

  try {
    const dto = await service.getInfo(ref);
    return NextResponse.json(dto);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Erreur inconnue";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ projectId: string }> },
): Promise<NextResponse> {
  const { projectId } = await params;
  const ref = await getWpProjectRef(projectId);

  if (!ref) {
    return NextResponse.json({ error: "Projet WordPress introuvable" }, { status: 404 });
  }

  const json = (await req.json()) as unknown;
  const parsed = wpActionSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Payload invalide", issues: parsed.error.issues }, { status: 400 });
  }

  try {
    const result = await service.executeAction(ref, parsed.data);
    return NextResponse.json(result);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Erreur inconnue";
    return NextResponse.json({ success: false, error: message }, { status: 500 });
  }
}