import { readdir, stat } from "node:fs/promises";
import { resolve } from "node:path";
import { Settings, FileCode } from "lucide-react";
import { PageLayout } from "@/components/shell/page-layout";
import { EmptyState } from "@/components/shell/empty-state";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface ConfigEntry {
  client: string;
  project: string;
  relativePath: string;
}

async function getConfigTree(): Promise<ConfigEntry[]> {
  const configsRoot = resolve(process.cwd(), "..", "configs");
  const entries: ConfigEntry[] = [];

  try {
    const clients = await readdir(configsRoot);
    for (const client of clients) {
      const clientDir = resolve(configsRoot, client);
      const clientStat = await stat(clientDir);
      if (!clientStat.isDirectory()) continue;

      const projects = await readdir(clientDir);
      for (const project of projects) {
        const composePath = resolve(
          clientDir,
          project,
          "docker-compose.yml",
        );
        try {
          await stat(composePath);
          entries.push({
            client,
            project,
            relativePath: `configs/${client}/${project}/docker-compose.yml`,
          });
        } catch {
          // No compose file in this directory, skip
        }
      }
    }
  } catch {
    // configs directory does not exist or is empty
  }

  return entries;
}

export default async function ConfigsPage() {
  const configs = await getConfigTree();

  return (
    <PageLayout
      title="Configurations"
      description="Fragments docker-compose générés par projet"
    >
      {configs.length === 0 ? (
        <EmptyState
          icon={<Settings className="size-6 text-muted-foreground" />}
          title="Aucune configuration"
          description="Les fragments docker-compose seront générés automatiquement lors de la création de projets."
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {configs.map((config) => (
            <Card key={`${config.client}/${config.project}`}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm">
                  <FileCode className="size-4" />
                  {config.project}
                </CardTitle>
                <CardDescription>
                  Client : {config.client}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <code className="text-xs text-muted-foreground">
                  {config.relativePath}
                </code>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </PageLayout>
  );
}
