"use server";

import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";

import { createProjectSchema } from "@/lib/validators/project";
import { generateSlug } from "@/lib/slug";
import { findNextAvailablePort, isPortInUse } from "@/lib/port";

import {
  buildProjectCreateArgs,
  type CreatedProject,
} from "@/lib/projects/buildProjectCreateArgs";

import { generateProjectInfra } from "@/lib/projects/generateProjectInfra";

interface ActionState {
  error: string | null;
}

function getStr(fd: FormData, key: string): string | undefined {
  const v = fd.get(key);
  if (typeof v !== "string") return undefined;
  const s = v.trim();
  return s === "" ? undefined : s;
}

export async function createProjectAction(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const portStr = getStr(formData, "port"); // "3001" | undefined

  const raw = {
    name: getStr(formData, "name"),
    clientId: getStr(formData, "clientId"),
    type: getStr(formData, "type") ?? "VITRINE",
    devMode: getStr(formData, "devMode") ?? "DEV_COMFORT",

    description: getStr(formData, "description"),
    domain: (formData.get("domain") ?? null), // <- laisse Zod gérer ""/trim/null
    gitRepo: getStr(formData, "gitRepo"),

    techStack: getStr(formData, "techStack"),
    deployTarget: getStr(formData, "deployTarget") ?? "DOCKER",
    category: getStr(formData, "category"), // si tu as le fix enum "" ci-dessus, tu peux passer formData.get

    runtime: {
      port: portStr ? Number(portStr) : null,
      localHost: null,
    },

    qualification: {
      modules: getStr(formData, "modules"),
      maintenanceLevel: getStr(formData, "maintenanceLevel"),
      estimatedBudget: getStr(formData, "estimatedBudget")
        ? Number(getStr(formData, "estimatedBudget"))
        : undefined,
    },
  };


  const parsed = createProjectSchema.safeParse(raw);
  if (!parsed.success) {
    return { error: parsed.error.errors[0]?.message ?? "Données invalides" };
  }

  const client = await prisma.client.findUnique({
    where: { id: parsed.data.clientId },
    select: { id: true, slug: true },
  });
  if (!client) return { error: "Le client sélectionné n'existe pas." };

  const slug = generateSlug(parsed.data.name);

  const existing = await prisma.project.findUnique({ where: { slug } });
  if (existing) return { error: `Un projet avec le slug "${slug}" existe déjà.` };

  // Port
  let port: number;
  const requestedPort = parsed.data.runtime?.port ?? null;
  if (requestedPort != null) {
    if (await isPortInUse(requestedPort)) {
      return { error: `Le port ${String(requestedPort)} est déjà utilisé par un autre projet.` };
    }
    port = requestedPort;
  } else {
    port = await findNextAvailablePort();
  }

  const built = buildProjectCreateArgs({
    formData,
    slug,
    port,
    data: parsed.data,
  });

  const project: CreatedProject = await prisma.project.create(built.createArgs);

  try {
    await generateProjectInfra({
      project,
      clientSlug: client.slug,
      port,
      domain: parsed.data.domain ?? null,
      type: project.type,
      techStack: built.techStack,
      deployTarget: built.deployTarget,
      devMode: parsed.data.devMode,
    });
  } catch (e: unknown) {
    console.error("Failed to generate infra configs for project:", project.id, e);
  }

  redirect(`/dashboard/clients/${parsed.data.clientId}`);
}
