"use server";

import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { updateProjectSchema } from "@/lib/validators/project";
import { generateSlug } from "@/lib/slug";
import { isPortInUse, findNextAvailablePort } from "@/lib/port";
import { generateTraefikConfig } from "@/lib/generators/traefik";

/** ───────────────────────────────────────────────────────────────
 * Types
 * ─────────────────────────────────────────────────────────────── */

interface ActionState {
  error: string | null;
}

/** ───────────────────────────────────────────────────────────────
 * FormData helpers (centralise les coercions)
 * ─────────────────────────────────────────────────────────────── */

function getStr(fd: FormData, key: string): string | undefined {
  const v = fd.get(key);
  if (typeof v !== "string") return undefined;
  const s = v.trim();
  return s === "" ? undefined : s;
}

function getStrOrNull(fd: FormData, key: string): string | null {
  const s = getStr(fd, key);
  return s ?? null;
}

function getNum(fd: FormData, key: string): number | undefined {
  const s = getStr(fd, key);
  if (!s) return undefined;
  const n = Number(s);
  return Number.isFinite(n) ? n : undefined;
}

function getBool(fd: FormData, key: string): boolean {
  // ton UI envoie "true"/"false"
  return fd.get(key) === "true";
}

/** ───────────────────────────────────────────────────────────────
 * Raw builder (shape attendue par Zod)
 * ─────────────────────────────────────────────────────────────── */

function buildRawFromFormData(formData: FormData) {
  const techStack = getStr(formData, "techStack"); // "WORDPRESS" | "NEXTJS" | ...
  const isWp = techStack === "WORDPRESS";

  return {
    name: formData.get("name"),
    type: formData.get("type"),
    status: formData.get("status"),
    description: getStr(formData, "description"),
    domain: getStrOrNull(formData, "domain"),
    gitRepo: getStr(formData, "gitRepo"),
    techStack: techStack ?? undefined,
    deployTarget: (getStr(formData, "deployTarget") ?? "DOCKER") as unknown,
    category: getStr(formData, "category"),

    runtime: {
      port: getNum(formData, "port") ?? null,
    },

    wpConfig: isWp
      ? {
          phpVersion: "8.3",
          wpHeadless: getBool(formData, "wpHeadless"),
          frontendStack: getStr(formData, "frontendStack"),
        }
      : undefined,

    qualification: {
      modules: getStr(formData, "modules"),
      maintenanceLevel: getStr(formData, "maintenanceLevel"),
      estimatedBudget: getNum(formData, "estimatedBudget"),
    },
  };
}

/** ───────────────────────────────────────────────────────────────
 * Action
 * ─────────────────────────────────────────────────────────────── */

export async function updateProjectAction(
  projectId: string,
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  // 1) Parse + validate
  const raw = buildRawFromFormData(formData);
  const parsed = updateProjectSchema.safeParse(raw);

  if (!parsed.success) {
    return { error: parsed.error.errors[0]?.message ?? "Données invalides" };
  }

  // 2) Load existing
  const existing = await prisma.project.findUnique({
    where: { id: projectId },
    include: {
      runtime: true,
      wpConfig: true,
      nextConfig: true,
      qualification: true,
    },
  });

  if (!existing) return { error: "Projet introuvable." };

  // 3) Compute slug
  const nextSlug = generateSlug(parsed.data.name);
  const slugChanged = nextSlug !== existing.slug;

  // 4) Resolve port
  const existingPort = existing.runtime?.port ?? null;
  const desiredPort = parsed.data.runtime?.port ?? null;

  let finalPort: number;
  if (desiredPort != null) {
    // port fourni -> check si changé
    if (desiredPort !== existingPort) {
      const used = await isPortInUse(desiredPort, projectId);
      if (used) {
        return { error: `Le port ${String(desiredPort)} est déjà utilisé par un autre projet.` };
      }
    }
    finalPort = desiredPort;
  } else if (existingPort != null) {
    // pas fourni -> on garde
    finalPort = existingPort;
  } else {
    // pas fourni et pas d'existant -> auto
    finalPort = await findNextAvailablePort();
  }

  const finalLocalHost = `${nextSlug}.localhost`;

  // 5) Transaction (slug unique + updates)
  try {
    await prisma.$transaction(async (tx) => {
      // slug unique only if changed
      if (slugChanged) {
        const slugTaken = await tx.project.findUnique({ where: { slug: nextSlug } });
        if (slugTaken) {
          // throw pour rollback
          throw new Error(`Un projet avec le slug "${nextSlug}" existe déjà.`);
        }
      }

      // base project update
      await tx.project.update({
        where: { id: projectId },
        data: {
          name: parsed.data.name,
          slug: nextSlug,
          type: parsed.data.type,
          status: parsed.data.status,
          description: parsed.data.description ?? null,
          domain: parsed.data.domain,
          gitRepo: parsed.data.gitRepo ?? null,
          techStack: parsed.data.techStack ?? null,
          deployTarget: parsed.data.deployTarget,
          category: parsed.data.category ?? null,
        },
      });

      // runtime upsert
      await tx.projectRuntime.upsert({
        where: { projectId },
        create: { projectId, port: finalPort, localHost: finalLocalHost },
        update: { port: finalPort, localHost: finalLocalHost },
      });

      // qualification upsert (toujours)
      await tx.projectQualification.upsert({
        where: { projectId },
        create: {
          projectId,
          modules: parsed.data.qualification?.modules ?? null,
          maintenanceLevel: parsed.data.qualification?.maintenanceLevel ?? null,
          estimatedBudget: parsed.data.qualification?.estimatedBudget ?? null,
        },
        update: {
          modules: parsed.data.qualification?.modules ?? null,
          maintenanceLevel: parsed.data.qualification?.maintenanceLevel ?? null,
          estimatedBudget: parsed.data.qualification?.estimatedBudget ?? null,
        },
      });

      // WP config: upsert only if WP, else cleanup if switching away
      const isWp = (parsed.data.techStack ?? null) === "WORDPRESS";
      const wpHeadless = isWp && (parsed.data.wpConfig?.wpHeadless ?? false);

      if (isWp) {
        await tx.wordpressConfig.upsert({
          where: { projectId },
          create: {
            projectId,
            phpVersion: parsed.data.wpConfig?.phpVersion ?? "8.3",
            wpHeadless,
            frontendStack: wpHeadless ? (parsed.data.wpConfig?.frontendStack ?? "NEXTJS") : null,
          },
          update: {
            phpVersion: parsed.data.wpConfig?.phpVersion ?? "8.3",
            wpHeadless,
            frontendStack: wpHeadless ? (parsed.data.wpConfig?.frontendStack ?? "NEXTJS") : null,
          },
        });

        // si tu veux: quand WP, tu peux décider de supprimer nextConfig (optionnel)
        // await tx.nextjsConfig.delete({ where: { projectId } }).catch(() => {});
      } else {
        // si le projet n'est plus WP, supprimer config WP si existante (optionnel mais propre)
        await tx.wordpressConfig.delete({ where: { projectId } }).catch(() => {});
      }

      // (Optionnel) Si tu veux gérer Next config ici aussi, même logique:
      // const isNext = (parsed.data.techStack ?? null) === "NEXTJS";
      // if (!isNext) await tx.nextjsConfig.delete({ where: { projectId } }).catch(() => {});
    });
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "Erreur inconnue";
    return { error: msg };
  }

  // 6) Traefik regen (non-fatal)
  try {
    await generateTraefikConfig();
  } catch {
    // ignore
  }

  redirect(`/dashboard/projects/${projectId}`);
}