//src/app/dashboard/projects/new/_components/step-summary.tsx
"use client";

import { useWizard } from "../_providers/wizard-provider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BudgetBreakdown } from "@/components/qualification/budget-breakdown";
import { AlertTriangle } from "lucide-react";
import { formatEur } from "@/lib/qualification-ui";
import {
  CATEGORY_COLORS,
  CATEGORY_LABELS,
  CATEGORY_SHORT,
  TECH_STACK_LABELS,
  DEPLOY_TARGET_LABELS,
  HOSTING_COSTS,
  MAINTENANCE_LABELS,
  MAINTENANCE_PRICES,
  BILLING_MODE_LABELS,
  computeStackMultiplier,
  getMultiplierLabel,
  resolveModulePrice,
  resolveModuleMonthly,
} from "@/lib/qualification";

export function StepSummary() {
  const {
    projectType,
    techStack,
    deployTarget,
    billingMode,
    setBillingMode,
    formFields,
    selectedModules,
    tierSelections,
    qualification,
  } = useWizard();

  if (!qualification || !projectType) return null;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">
            Résumé de qualification
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* ── Nom du projet ───────────────────────── */}
          <div className="flex items-center justify-between rounded-lg border p-3">
            <span className="text-sm text-muted-foreground">Projet</span>
            <span className="text-sm font-medium">
              {formFields.name || "—"}
            </span>
          </div>

          {/* ── Catégorie ───────────────────────────── */}
          <div className="flex items-center justify-between rounded-lg border p-3">
            <span className="text-sm text-muted-foreground">
              Catégorie finale
            </span>
            <Badge
              className={
                CATEGORY_COLORS[qualification.finalCategory]
              }
            >
              {CATEGORY_LABELS[qualification.finalCategory]}
            </Badge>
          </div>

          {qualification.wasRequalified && (
            <div className="flex items-center gap-2 text-xs text-amber-600 dark:text-amber-400">
              <AlertTriangle className="size-3.5" />
              Requalifié depuis{" "}
              {CATEGORY_SHORT[qualification.initialCategory]} par :{" "}
              {qualification.requalifyingModules
                .map((m) => m.name)
                .join(", ")}
            </div>
          )}

          {/* ── Modules ─────────────────────────────── */}
          {qualification.modules.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm font-medium">
                Modules ({String(qualification.modules.length)})
              </p>
              <div className="space-y-1.5">
                {qualification.modules.map((m) => {
                  const tierSel = tierSelections[m.id];
                  const resolved = resolveModulePrice(m, techStack, tierSel);
                  const monthly = resolveModuleMonthly(m, tierSel);
                  const setupTier =
                    tierSel.setupTierId && m.setupTiers
                      ? m.setupTiers.find(
                          (t) => t.id === tierSel.setupTierId,
                        )
                      : null;
                  const subTier =
                    tierSel.subTierId && m.subscriptionTiers
                      ? m.subscriptionTiers.find(
                          (t) => t.id === tierSel.subTierId,
                        )
                      : null;

                  return (
                    <div
                      key={m.id}
                      className="flex flex-col gap-0.5 rounded-md border p-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{m.name}</span>
                        <span className="font-medium">
                          {formatEur(resolved.setup)}
                        </span>
                      </div>
                      {setupTier && (
                        <div className="flex items-center justify-between text-muted-foreground">
                          <span>↳ Setup : {setupTier.name}</span>
                          <span>{formatEur(resolved.setup)}</span>
                        </div>
                      )}
                      {subTier && (
                        <div className="flex items-center justify-between text-amber-600 dark:text-amber-400">
                          <span>↳ Abo : {subTier.name}</span>
                          <span>{String(monthly)} €/mois</span>
                        </div>
                      )}
                      {!subTier && monthly > 0 && (
                        <div className="flex items-center justify-between text-amber-600 dark:text-amber-400">
                          <span>↳ Récurrent</span>
                          <span>{String(monthly)} €/mois</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── Budget ──────────────────────────────── */}
          <BudgetBreakdown
            budget={qualification.budget}
            moduleCount={selectedModules.size}
            projectType={projectType}
            techStack={techStack}
            variant="full"
          />

          {/* ── Mode de facturation ─────────────────── */}
          <div className="flex items-center justify-between rounded-lg border p-4">
            <div>
              <p className="text-xs text-muted-foreground">
                Mode de facturation
              </p>
              <p className="text-sm font-medium">
                {BILLING_MODE_LABELS[billingMode]}
              </p>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                setBillingMode(
                  billingMode === "SOLO" ? "SOUS_TRAITANT" : "SOLO",
                );
              }}
            >
              Changer
            </Button>
          </div>

          {/* ── Splits (sous-traitant) ──────────────── */}
          {qualification.splits && (
            <div className="grid gap-3 rounded-lg border border-dashed p-4 sm:grid-cols-2">
              <div>
                <p className="text-xs text-muted-foreground">
                  Split base (toi / agence)
                </p>
                <p className="text-sm font-medium">
                  {String(qualification.splits.baseSplitPrestataire)} % /{" "}
                  {String(qualification.splits.baseSplitAgence)} %
                </p>
              </div>
              {qualification.budget.modulesTotal > 0 && (
                <div>
                  <p className="text-xs text-muted-foreground">
                    Split modules (toi / agence)
                  </p>
                  <p className="text-sm font-medium">
                    {formatEur(qualification.splits.modulesSplitPrestataire)}{" "}
                    / {formatEur(qualification.splits.modulesSplitAgence)}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* ── Maintenance ─────────────────────────── */}
          <div className="flex items-center justify-between rounded-lg border p-3">
            <span className="text-sm text-muted-foreground">
              Maintenance
            </span>
            <div className="text-right text-sm">
              <p className="font-medium">
                {MAINTENANCE_LABELS[qualification.maintenance]}
              </p>
              <p className="text-xs text-muted-foreground">
                {MAINTENANCE_PRICES[qualification.maintenance]}
              </p>
            </div>
          </div>

          {/* ── Stack ───────────────────────────────── */}
          <div className="flex items-center justify-between rounded-lg border p-3">
            <span className="text-sm text-muted-foreground">Stack</span>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">
                {TECH_STACK_LABELS[techStack]}
              </span>
              {computeStackMultiplier(projectType, techStack) !== 1 && (
                <Badge
                  variant="outline"
                  className="text-[10px] text-muted-foreground"
                >
                  {getMultiplierLabel(projectType, techStack)} sur la base
                </Badge>
              )}
            </div>
          </div>

          {/* ── Hébergement (client) ────────────────── */}
          <div className="rounded-lg border border-dashed p-3 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">
                Hébergement
              </span>
              <span className="text-sm font-medium">
                {DEPLOY_TARGET_LABELS[deployTarget]}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Coût indicatif (à la charge du client)</span>
              <span>
                {HOSTING_COSTS[deployTarget].range}
              </span>
            </div>
            <p className="text-[10px] text-muted-foreground/80 italic">
              L&apos;hébergement et le domaine sont la propriété du client et
              mentionnés séparément dans le devis.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
