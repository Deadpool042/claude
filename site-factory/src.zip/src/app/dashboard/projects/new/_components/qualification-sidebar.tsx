"use client";

import { useWizard } from "../_providers/wizard-provider";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShieldCheck, AlertTriangle, Gauge } from "lucide-react";
import { formatEur } from "@/lib/qualification-ui";
import {
  CATEGORY_COLORS,
  CATEGORY_LABELS,
  CATEGORY_SHORT,
  MAINTENANCE_LABELS,
  MAINTENANCE_PRICES,
  TECH_STACK_LABELS,
  DEPLOY_TARGET_LABELS,
  computeStackMultiplier,
  getMultiplierLabel,
} from "@/lib/qualification";

/**
 * Panneau latéral de qualification.
 * Rendu en parallèle du contenu wizard via le slot @sidebar.
 * Affiche en temps réel : catégorie, budget, maintenance, stack.
 */
export function QualificationSidebar() {
  const {
    projectType,
    techStack,
    deployTarget,
    selectedModules,
    qualification,
  } = useWizard();

  if (!qualification || !projectType) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-8 text-center text-sm text-muted-foreground">
          <Gauge className="mx-auto mb-2 size-6 opacity-40" />
          Sélectionnez un type de projet pour voir la qualification en temps
          réel.
        </CardContent>
      </Card>
    );
  }

  const multiplier = computeStackMultiplier(projectType, techStack);

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm">Qualification live</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* ── Catégorie ────────────────────────────── */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">Catégorie</span>
          <Badge
            className={CATEGORY_COLORS[qualification.finalCategory]}
          >
            {CATEGORY_LABELS[qualification.finalCategory]}
          </Badge>
        </div>

        {qualification.wasRequalified && (
          <div className="flex items-center gap-1.5 text-[10px] text-amber-600 dark:text-amber-400">
            <AlertTriangle className="size-3" />
            {CATEGORY_SHORT[qualification.initialCategory]} →{" "}
            {CATEGORY_SHORT[qualification.finalCategory]}
          </div>
        )}

        {/* ── Budget ───────────────────────────────── */}
        <div className="space-y-1.5 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Base</span>
            <span>{formatEur(qualification.budget.base)}</span>
          </div>
          {qualification.budget.modulesTotal > 0 && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">
                Modules ({String(selectedModules.size)})
              </span>
              <span>
                + {formatEur(qualification.budget.modulesTotal)}
              </span>
            </div>
          )}
          {qualification.budget.deployCost > 0 && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Mise en prod.</span>
              <span>+ {formatEur(qualification.budget.deployCost)}</span>
            </div>
          )}
          <div className="flex justify-between border-t pt-1 font-medium">
            <span>Total</span>
            <span>{formatEur(qualification.budget.grandTotal)}</span>
          </div>
          {qualification.budget.monthlyTotal > 0 && (
            <div className="flex justify-between text-amber-600 dark:text-amber-400">
              <span>Récurrent</span>
              <span>
                {formatEur(qualification.budget.monthlyTotal)}/mois
              </span>
            </div>
          )}
        </div>

        {/* ── Tech ──────────────────────────────────── */}
        <div className="border-t pt-2 space-y-1.5 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Stack</span>
            <span className="font-medium">
              {TECH_STACK_LABELS[techStack]}
            </span>
          </div>
          {multiplier !== 1 && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Coeff.</span>
              <span>{getMultiplierLabel(projectType, techStack)}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span className="text-muted-foreground">Déploiement</span>
            <span>{DEPLOY_TARGET_LABELS[deployTarget]}</span>
          </div>
        </div>

        {/* ── Maintenance ───────────────────────────── */}
        <div className="border-t pt-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1 text-muted-foreground">
            <ShieldCheck className="size-3" />
            Maintenance
          </div>
          <div className="text-right">
            <p className="font-medium">
              {MAINTENANCE_LABELS[qualification.maintenance]}
            </p>
            <p className="text-[10px] text-muted-foreground">
              {MAINTENANCE_PRICES[qualification.maintenance]}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
