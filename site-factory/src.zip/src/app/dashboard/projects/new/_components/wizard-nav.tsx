//src/app/dashboard/projects/new/_components/wizard-nav.tsx
"use client";

import { useWizard } from "../_providers/wizard-provider";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  ArrowRight,
  FolderPlus,
  Loader2,
  AlertTriangle,
} from "lucide-react";

export function WizardNav() {
  const {
    step,
    prev,
    next,
    canGoNext,
    isPending,
    actionError,
    formAction,
    formFields,
    projectType,
    techStack,
    deployTarget,
    isHeadless,
    selectedModules,
    tierSelections,
    qualification,
  } = useWizard();

  return (
    <>
      {/* ── Error ────────────────────────────────── */}
      {actionError && (
        <div className="mt-4 flex items-center gap-2 rounded-lg border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          <AlertTriangle className="size-4 shrink-0" />
          {actionError}
        </div>
      )}

      {/* ── Navigation ───────────────────────────── */}
      <div className="mt-6 flex items-center justify-between">
        <Button
          type="button"
          variant="outline"
          onClick={prev}
          disabled={step === 0}
          className="gap-1.5"
        >
          <ArrowLeft className="size-4" />
          Précédent
        </Button>

        {step < 3 ? (
          <Button
            type="button"
            onClick={next}
            disabled={!canGoNext}
            className="gap-1.5"
          >
            Suivant
            <ArrowRight className="size-4" />
          </Button>
        ) : (
          <form action={formAction}>
            {/* Hidden fields for the server action */}
            <input type="hidden" name="name" value={formFields.name} />
            <input
              type="hidden"
              name="clientId"
              value={formFields.clientId}
            />
            <input
              type="hidden"
              name="type"
              value={projectType ?? "VITRINE"}
            />
            <input
              type="hidden"
              name="description"
              value={formFields.description}
            />
            <input type="hidden" name="domain" value={formFields.domain} />
            <input type="hidden" name="port" value={formFields.port} />
            <input
              type="hidden"
              name="gitRepo"
              value={formFields.gitRepo}
            />
            <input type="hidden" name="techStack" value={techStack} />
            <input
              type="hidden"
              name="deployTarget"
              value={deployTarget}
            />
            <input
              type="hidden"
              name="wpHeadless"
              value={isHeadless ? "true" : "false"}
            />
            {isHeadless && techStack !== "WORDPRESS" && (
              <input
                type="hidden"
                name="frontendStack"
                value={techStack}
              />
            )}
            <input
              type="hidden"
              name="category"
              value={qualification?.finalCategory ?? "CAT1"}
            />
            <input
              type="hidden"
              name="modules"
              value={JSON.stringify(Array.from(selectedModules))}
            />
            <input
              type="hidden"
              name="tierSelections"
              value={JSON.stringify(tierSelections)}
            />
            <input
              type="hidden"
              name="maintenanceLevel"
              value={qualification?.maintenance ?? "STANDARD"}
            />
            <input
              type="hidden"
              name="estimatedBudget"
              value={String(qualification?.budget.grandTotal ?? 0)}
            />

            <Button
              type="submit"
              size="lg"
              className="gap-2"
              disabled={isPending}
            >
              {isPending ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <FolderPlus className="size-4" />
              )}
              {isPending ? "Création…" : "Créer le projet"}
            </Button>
          </form>
        )}
      </div>
    </>
  );
}
