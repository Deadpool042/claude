//src/app/dashboard/projects/new/_components/step-type-stack.tsx
"use client";

import { useWizard } from "../_providers/wizard-provider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, Wrench, Layers, Info } from "lucide-react";
import {
  PROJECT_TYPE_OPTIONS,
  TECH_STACK_OPTIONS,
  formatEur,
} from "@/lib/qualification-ui";
import {
  ALLOWED_STACKS,
  CATEGORY_COLORS,
  CATEGORY_LABELS,
  CATEGORY_SHORT,
  computeStackMultiplier,
  getMultiplierLabel,
  type Category,
} from "@/lib/qualification";

export function StepTypeStack() {
  const {
    projectType,
    changeProjectType,
    techStack,
    setTechStack,
    wpHeadless,
    setWpHeadless,
    qualification,
  } = useWizard();

  return (
    <div className="space-y-4">
      {/* ── Type de projet ─────────────────────────── */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className="flex size-7 items-center justify-center rounded-lg bg-primary/10">
              <Zap className="size-4 text-primary" />
            </div>
            Quel type de projet ?
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2">
            {PROJECT_TYPE_OPTIONS.map((pt) => {
              const initialCat: Category =
                pt.value === "APP" ? "CAT3" : "CAT1";
              return (
                <button
                  key={pt.value}
                  type="button"
                  onClick={() => { changeProjectType(pt.value); }}
                  className={`group relative flex flex-col items-start gap-2 rounded-lg border-2 p-4 text-left transition-all ${
                    projectType === pt.value
                      ? "border-primary bg-primary/5 shadow-sm"
                      : "border-border hover:border-muted-foreground/30"
                  }`}
                >
                  <div className="flex w-full items-center justify-between">
                    <span className="text-xl">{pt.icon}</span>
                    <Badge
                      variant="outline"
                      className={`text-[10px] ${CATEGORY_COLORS[initialCat]}`}
                    >
                      {CATEGORY_SHORT[initialCat]}
                    </Badge>
                  </div>
                  <span className="text-sm font-medium">{pt.label}</span>
                  <span className="text-xs text-muted-foreground">
                    {pt.desc}
                  </span>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ── Stack technique ────────────────────────── */}
      {projectType && (
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-base">
              <div className="flex size-7 items-center justify-center rounded-lg bg-blue-500/10">
                <Wrench className="size-4 text-blue-500" />
              </div>
              Stack technique
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              Le stack n&apos;affecte pas la catégorie — il détermine
              l&apos;implémentation technique et le tarif.
              {projectType === "APP" && (
                <span className="block mt-1 text-amber-600 dark:text-amber-400">
                  Les applications sur mesure ne sont pas disponibles en
                  WordPress.
                </span>
              )}
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2">
              {TECH_STACK_OPTIONS.filter((ts) =>
                ALLOWED_STACKS[projectType].includes(ts.value),
              ).map((ts) => {
                const coeff = computeStackMultiplier(projectType, ts.value);
                const label = getMultiplierLabel(projectType, ts.value);
                return (
                  <button
                    key={ts.value}
                    type="button"
                    onClick={() => { setTechStack(ts.value); }}
                    className={`group relative flex flex-col items-start gap-2 rounded-lg border-2 p-4 text-left transition-all ${
                      techStack === ts.value
                        ? "border-primary bg-primary/5 shadow-sm"
                        : "border-border hover:border-muted-foreground/30"
                    }`}
                  >
                    <div className="flex w-full items-center justify-between">
                      <span className="text-xl">{ts.icon}</span>
                      {coeff !== 1 && (
                        <Badge
                          variant="outline"
                          className="text-[10px] text-muted-foreground"
                        >
                          {label}
                        </Badge>
                      )}
                    </div>
                    <span className="text-sm font-medium">{ts.label}</span>
                    <span className="text-xs text-muted-foreground">
                      {ts.desc}
                    </span>
                    {projectType === "ECOM" && ts.value !== "WORDPRESS" && (
                      <span className="text-[10px] text-amber-600 dark:text-amber-400">
                        + surcoût e-com (Medusa, Snipcart…)
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── WordPress mode : Classique / Headless ─── */}
      {projectType && techStack === "WORDPRESS" && (
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-base">
              <div className="flex size-7 items-center justify-center rounded-lg bg-blue-500/10">
                <Layers className="size-4 text-blue-500" />
              </div>
              Mode WordPress
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              Le mode headless utilise WordPress comme CMS API et un frontend JS
              séparé.
            </p>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => { setWpHeadless(false); }}
                className={`flex flex-col items-center gap-1.5 rounded-lg border-2 p-3 text-center transition-all ${
                  !wpHeadless
                    ? "border-blue-500 bg-blue-500/10 shadow-sm"
                    : "border-border hover:border-muted-foreground/30"
                }`}
              >
                <span className="text-lg">🎨</span>
                <span className="text-sm font-medium">Classique</span>
                <span className="text-xs text-muted-foreground">
                  Thème FSE natif, rendu serveur
                </span>
              </button>
              <button
                type="button"
                onClick={() => { setWpHeadless(true); }}
                className={`flex flex-col items-center gap-1.5 rounded-lg border-2 p-3 text-center transition-all ${
                  wpHeadless
                    ? "border-blue-500 bg-blue-500/10 shadow-sm"
                    : "border-border hover:border-muted-foreground/30"
                }`}
              >
                <span className="text-lg">⚡</span>
                <span className="text-sm font-medium">Headless</span>
                <span className="text-xs text-muted-foreground">
                  WP API + frontend JS
                </span>
              </button>
            </div>
            {wpHeadless && (
              <p className="text-xs text-blue-600 dark:text-blue-400">
                2 services nécessaires : WP backend (PHP) + frontend JS.
                Hébergement split (mutualisé + Vercel) ou unifié (Docker/VPS).
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* ── Indicateur de catégorie ─────────────────── */}
      {projectType && qualification && (
        <div
          className={`flex items-center gap-3 rounded-lg border p-3 ${CATEGORY_COLORS[qualification.initialCategory]}`}
        >
          <Info className="size-4 shrink-0" />
          <div className="text-sm">
            <span className="font-medium">
              {CATEGORY_LABELS[qualification.initialCategory]}
            </span>
            <span className="mx-1">—</span>
            <span className="text-xs opacity-80">
              Budget de base : {formatEur(qualification.budget.base)}
            </span>
            {computeStackMultiplier(projectType, techStack) !== 1 && (
              <span className="ml-1 text-[10px] opacity-60">
                (×{computeStackMultiplier(projectType, techStack)})
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
