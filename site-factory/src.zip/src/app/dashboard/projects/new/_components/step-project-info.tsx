//src/app/dashboard/projects/new/_components/step-project-info.tsx
"use client";

import { useWizard } from "../_providers/wizard-provider";
import { ClientSelect } from "./client-select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  FolderPlus,
  Globe,
  GitBranch,
  Server,
  Monitor,
  Rocket,
} from "lucide-react";
import { DEPLOY_TARGET_OPTIONS } from "@/lib/qualification-ui";
import {
  PROJECT_TYPE_LABELS,
  TECH_STACK_LABELS,
  HOSTING_COSTS,
  HOSTING_COST_WP_HEADLESS,
} from "@/lib/qualification";

export function StepProjectInfo() {
  const {
    projectType,
    techStack,
    wpHeadless,
    deployTarget,
    setDeployTarget,
    allowedDeploys,
    formFields,
    setFormFields,
  } = useWizard();

  return (
    <div className="space-y-4">
      {/* ── Identité du projet ─────────────────────── */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className="flex size-7 items-center justify-center rounded-lg bg-primary/10">
              <FolderPlus className="size-4 text-primary" />
            </div>
            Identité du projet
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="name">Nom du projet *</Label>
            <Input
              id="name"
              name="name"
              placeholder="Ex: Site Vitrine Acme"
              required
              minLength={2}
              maxLength={100}
              autoFocus
              value={formFields.name}
              onChange={(e) => {
                setFormFields((f) => ({ ...f, name: e.target.value }));
              }}
            />
            <p className="text-xs text-muted-foreground">
              Le slug sera généré automatiquement.
            </p>
          </div>

          <div className="space-y-2">
            <ClientSelect
              defaultClientId={formFields.clientId}
              onChange={(id) => {
                setFormFields((f) => ({ ...f, clientId: id }));
              }}
            />
          </div>

          <div className="space-y-2">
            <Label>Type</Label>
            <div className="flex h-9 items-center rounded-md border bg-muted/50 px-3 text-sm text-muted-foreground">
              {projectType ? PROJECT_TYPE_LABELS[projectType] : "—"}
            </div>
          </div>

          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="description">Description (optionnel)</Label>
            <Textarea
              id="description"
              name="description"
              placeholder="Brève description du projet…"
              rows={2}
              maxLength={2000}
              value={formFields.description}
              onChange={(e) => {
                setFormFields((f) => ({
                  ...f,
                  description: e.target.value,
                }));
              }}
            />
          </div>
        </CardContent>
      </Card>

      {/* ── Cible de déploiement ───────────────────── */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className="flex size-7 items-center justify-center rounded-lg bg-emerald-500/10">
              <Rocket className="size-4 text-emerald-500" />
            </div>
            Déploiement
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            L&apos;hébergement et le domaine sont à la charge et la propriété du
            client. Ils seront mentionnés séparément dans le devis.
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-3">
            {DEPLOY_TARGET_OPTIONS.filter((t) =>
              allowedDeploys.includes(t.value),
            ).map((t) => {
              const Icon = t.icon;
              const isWpH = wpHeadless && techStack === "WORDPRESS";
              const hostCost: { label: string; range: string } = isWpH
                ? HOSTING_COST_WP_HEADLESS[t.value]
                : HOSTING_COSTS[t.value];
              return (
                <button
                  key={t.value}
                  type="button"
                  onClick={() => { setDeployTarget(t.value); }}
                  className={`group flex flex-col items-center gap-2 rounded-lg border-2 p-3 text-center transition-all ${
                    deployTarget === t.value
                      ? "border-primary bg-primary/5 shadow-sm"
                      : "border-border hover:border-muted-foreground/30"
                  }`}
                >
                  <Icon
                    className={`size-5 ${deployTarget === t.value ? "text-primary" : "text-muted-foreground"}`}
                  />
                  <span className="text-sm font-medium">
                    {isWpH ? hostCost.label : t.label}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {!isWpH && t.desc}
                  </span>
                  <span className="text-[10px] text-muted-foreground/70">
                    {hostCost.range}
                  </span>
                </button>
              );
            })}
          </div>
          {allowedDeploys.length < 3 && (
            <p className="mt-2 text-xs text-amber-600 dark:text-amber-400">
              Certaines cibles ne sont pas disponibles pour{" "}
              {TECH_STACK_LABELS[techStack]}
              {wpHeadless ? " (headless)" : ""}.
            </p>
          )}
        </CardContent>
      </Card>

      {/* ── Réseau & dépôt ─────────────────────────── */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-base">
            <div className="flex size-7 items-center justify-center rounded-lg bg-orange-500/10">
              <Monitor className="size-4 text-orange-500" />
            </div>
            Réseau & dépôt
            <span className="text-xs font-normal text-muted-foreground">
              (optionnel)
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="domain" className="flex items-center gap-1.5">
              <Globe className="size-3.5 text-muted-foreground" />
              Domaine
            </Label>
            <Input
              id="domain"
              name="domain"
              placeholder="Ex: acme.localhost"
              value={formFields.domain}
              onChange={(e) => {
                setFormFields((f) => ({ ...f, domain: e.target.value }));
              }}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="port" className="flex items-center gap-1.5">
              <Server className="size-3.5 text-muted-foreground" />
              Port
            </Label>
            <Input
              id="port"
              name="port"
              type="number"
              min={3001}
              max={3999}
              placeholder="Auto (3001–3999)"
              value={formFields.port}
              onChange={(e) => {
                setFormFields((f) => ({ ...f, port: e.target.value }));
              }}
            />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="gitRepo" className="flex items-center gap-1.5">
              <GitBranch className="size-3.5 text-muted-foreground" />
              Dépôt Git
            </Label>
            <Input
              id="gitRepo"
              name="gitRepo"
              type="url"
              placeholder="https://github.com/…"
              value={formFields.gitRepo}
              onChange={(e) => {
                setFormFields((f) => ({ ...f, gitRepo: e.target.value }));
              }}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
