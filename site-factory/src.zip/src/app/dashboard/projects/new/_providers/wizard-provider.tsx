"use client";

import {
  createContext,
  useContext,
  useState,
  useCallback,
  useActionState,
  type Dispatch,
  type SetStateAction,
  type ReactNode,
} from "react";
import { useSearchParams } from "next/navigation";
import { createProjectAction } from "../../_actions/create-project";
import { useModules } from "@/hooks/use-modules";
import { useQualification } from "@/hooks/use-qualification";
import {
  getAllowedDeployTargets,
  ALLOWED_STACKS,
  type ProjectType,
  type TechStack,
  type BillingMode,
  type DeployTarget,
  type ModuleTierSelection,
  type QualificationResult,
} from "@/lib/qualification";

// ── Types ──────────────────────────────────────────────────────────

export interface FormFields {
  name: string;
  clientId: string;
  description: string;
  domain: string;
  port: string;
  gitRepo: string;
}

export interface WizardContextType {
  /* Navigation */
  step: number;
  setStep: (step: number) => void;
  next: () => void;
  prev: () => void;
  canGoNext: boolean;

  /* Project config */
  projectType: ProjectType | null;
  changeProjectType: (type: ProjectType) => void;
  techStack: TechStack;
  setTechStack: (stack: TechStack) => void;
  wpHeadless: boolean;
  setWpHeadless: (headless: boolean) => void;
  deployTarget: DeployTarget;
  setDeployTarget: (target: DeployTarget) => void;
  billingMode: BillingMode;
  setBillingMode: (mode: BillingMode) => void;

  /* Modules */
  selectedModules: Set<string>;
  toggleModule: (id: string) => void;
  tierSelections: Record<string, ModuleTierSelection>;
  setTierSelections: Dispatch<SetStateAction<Record<string, ModuleTierSelection>>>;

  /* Form fields */
  formFields: FormFields;
  setFormFields: Dispatch<SetStateAction<FormFields>>;

  /* Derived */
  qualification: QualificationResult | null;
  allowedDeploys: DeployTarget[];
  isHeadless: boolean;

  /* Form submission */
  formAction: (formData: FormData) => void;
  isPending: boolean;
  actionError: string | null;
}

// ── Context ────────────────────────────────────────────────────────

const WizardContext = createContext<WizardContextType | null>(null);

export function useWizard(): WizardContextType {
  const ctx = useContext(WizardContext);
  if (!ctx) throw new Error("useWizard must be used within WizardProvider");
  return ctx;
}

// ── Provider ───────────────────────────────────────────────────────

export function WizardProvider({ children }: { children: ReactNode }) {
  const searchParams = useSearchParams();
  const defaultClientId = searchParams.get("clientId") ?? "";

  const [state, formAction, isPending] = useActionState(createProjectAction, {
    error: null,
  });

  // ── Navigation ─────────────────────────────────────────────
  const [step, setStep] = useState(0);

  // ── Project config ─────────────────────────────────────────
  const [projectType, setProjectType] = useState<ProjectType | null>(null);
  const [techStack, setTechStackRaw] = useState<TechStack>("WORDPRESS");
  const [wpHeadless, setWpHeadless] = useState(false);
  const [deployTarget, setDeployTargetRaw] = useState<DeployTarget>("DOCKER");
  const [billingMode, setBillingMode] = useState<BillingMode>("SOLO");

  // ── Modules (shared hook) ──────────────────────────────────
  const {
    selectedModules,
    tierSelections,
    setTierSelections,
    toggleModule,
    clearModules,
  } = useModules();

  // ── Form fields ────────────────────────────────────────────
  const [formFields, setFormFields] = useState<FormFields>({
    name: "",
    clientId: defaultClientId,
    description: "",
    domain: "",
    port: "",
    gitRepo: "",
  });

  // ── Derived values ─────────────────────────────────────────
  const allowedDeploys = getAllowedDeployTargets(techStack, wpHeadless);

  // Auto-reset deploy target if incompatible
  if (!allowedDeploys.includes(deployTarget)) {
    setDeployTargetRaw(allowedDeploys[0]);
  }

  const isHeadless =
    (techStack === "WORDPRESS" && wpHeadless) || techStack !== "WORDPRESS";

  // ── Qualification (shared hook) ────────────────────────────
  const qualification = useQualification({
    projectType,
    techStack,
    selectedModules,
    billingMode,
    deployTarget,
    wpHeadless,
    tierSelections,
  });

  // ── Actions ────────────────────────────────────────────────

  /** Change le type de projet — reset modules + auto-corrige le stack */
  const changeProjectType = useCallback(
    (type: ProjectType) => {
      setProjectType(type);
      clearModules();
      setTechStackRaw((curr) => {
        if (!ALLOWED_STACKS[type].includes(curr))
          return ALLOWED_STACKS[type][0];
        return curr;
      });
    },
    [clearModules],
  );

  /** Change le stack technique — désactive headless pour les stacks non-WP */
  const setTechStack = useCallback((stack: TechStack) => {
    setTechStackRaw(stack);
    if (stack !== "WORDPRESS") setWpHeadless(false);
  }, []);

  const setDeployTarget = useCallback((target: DeployTarget) => {
    setDeployTargetRaw(target);
  }, []);

  // ── Navigation helpers ─────────────────────────────────────!

  const canGoNext = (() => {
    if (step === 0) return projectType !== null;
    if (step === 2)
      return (
        formFields.name.trim().length >= 2 && formFields.clientId.length > 0
      );
    return true;
  })();

  const next = useCallback(() => {
    if (!canGoNext) return;
    setStep((s) => Math.min(s + 1, 3));
  }, [canGoNext]);

  const prev = useCallback(() => {
    setStep((s) => Math.max(s - 1, 0));
  }, []);

  // ── Render ─────────────────────────────────────────────────

  return (
    <WizardContext.Provider
      value={{
        step,
        setStep,
        next,
        prev,
        canGoNext,
        projectType,
        changeProjectType,
        techStack,
        setTechStack,
        wpHeadless,
        setWpHeadless,
        deployTarget,
        setDeployTarget,
        billingMode,
        setBillingMode,
        selectedModules,
        toggleModule,
        tierSelections,
        setTierSelections,
        formFields,
        setFormFields,
        qualification,
        allowedDeploys,
        isHeadless,
        formAction,
        isPending,
        actionError: state.error,
      }}
    >
      {children}
    </WizardContext.Provider>
  );
}
