import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { PageLayout } from "@/components/shell/page-layout";
import { BreadcrumbOverride } from "@/components/shell/breadcrumb-context";
import { ProjectEditForm } from "./_components/project-edit-form";

interface EditProjectPageProps {
  params: Promise<{ projectId: string }>;
}

export default async function EditProjectPage({
  params,
}: EditProjectPageProps) {
  const { projectId } = await params;

  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: { client: true, runtime: true, wpConfig: true, qualification: true },
  });

  if (!project) {
    notFound();
  }

  return (
    <>
      <BreadcrumbOverride segments={{ [projectId]: project.name }} />
      <PageLayout
        title={`Modifier ${project.name}`}
        description={`Client : ${project.client.name} — Slug : ${project.slug}`}
      >
        <ProjectEditForm
          project={{
            id: project.id,
            name: project.name,
            type: project.type,
            status: project.status,
            description: project.description,
            domain: project.domain,
            port: project.runtime?.port ?? null,
            gitRepo: project.gitRepo,
            techStack: project.techStack,
            deployTarget: project.deployTarget,
            clientId: project.clientId,
            category: project.category,
            wpHeadless: project.wpConfig?.wpHeadless ?? false,
            frontendStack: project.wpConfig?.frontendStack ?? null,
            modules: project.qualification?.modules ?? null,
            maintenanceLevel: project.qualification?.maintenanceLevel ?? null,
            estimatedBudget: project.qualification?.estimatedBudget ?? null,
          }}
        />
      </PageLayout>
    </>
  );
}
