"use client";

import { useActionState, useCallback } from "react";
import { Database, Gauge, HardDrive, Mail, Search, TableProperties, Zap, ArrowLeftRight } from "lucide-react";
import { updateProjectConfigAction } from "../../_actions/update-config";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import type { ProjectConfigPanelProps } from "./project-config-panel.types";
import { useProjectConfigPanelState } from "./use-project-config-panel";
import { DeployTargetBanner } from "./deploy-target-banner";
import { ServiceCatalogSection } from "./service-catalog-section";
import { EnvVarsSection } from "./env-vars-section";

// icon renderer (UI concern only)
const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  Database,
  TableProperties,
  Zap,
  Mail,
  Search,
  HardDrive,
  ArrowLeftRight,
  Gauge,
};
function renderIcon(name: string) {
  const Icon = ICONS[name];
  return Icon ? <Icon className="size-4" /> : null;
}

export function ProjectConfigPanel(props: ProjectConfigPanelProps) {
  const { projectId, techStack, deployTarget } = props;

  const boundAction = useCallback(
    (prev: { error: string | null; success?: boolean }, formData: FormData) =>
      updateProjectConfigAction(projectId, prev, formData),
    [projectId],
  );

  const [state, formAction, isPending] = useActionState(boundAction, { error: null });

  const vm = useProjectConfigPanelState(props);

  return (
    <Card>
      <form action={formAction}>
        <input type="hidden" name="dbType" value={vm.dbType} />
        <input type="hidden" name="enabledServices" value={Array.from(vm.enabledServices).join(",")} />

        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CardTitle className="text-lg">Configuration Docker</CardTitle>
              {techStack ? (
                <Badge variant="secondary">
                  {vm.isWordpress ? "WordPress" : vm.isNextjs ? "Next.js" : techStack}
                </Badge>
              ) : null}
            </div>

            {techStack ? (
              <div className="flex gap-1">
                <Button
                  type="button"
                  variant={vm.activeProfile === "dev" ? "default" : "outline"}
                  size="sm"
                  onClick={() => vm.setActiveProfile(vm.activeProfile === "dev" ? null : "dev")}
                >
                  Vue Local
                </Button>
                <Button
                  type="button"
                  variant={vm.activeProfile === "prod-like" ? "default" : "outline"}
                  size="sm"
                  onClick={() => vm.setActiveProfile(vm.activeProfile === "prod-like" ? null : "prod-like")}
                >
                  Vue Prod-like
                </Button>
              </div>
            ) : null}
          </div>

          <CardDescription>
            {vm.activeProfile === "dev"
              ? "Prévisualisation local — services inclus dans docker-compose.local.yml"
              : vm.activeProfile === "prod-like"
                ? "Prévisualisation prod-like — services inclus dans docker-compose.prod-like.yml (dérivé automatiquement)"
                : "Sélectionnez les services Docker. Deux fichiers seront générés : local (tous les services) et prod-like (dérivé automatiquement)."}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {techStack ? (
            <DeployTargetBanner
              techStack={techStack}
              deployTarget={deployTarget}
              activeProfile={vm.activeProfile}
              compatibleCount={vm.compatibleServices.length}
            />
          ) : null}

          {techStack ? (
            <ServiceCatalogSection
              groups={vm.groups}
              enabledServices={vm.enabledServices}
              compatibleServices={vm.compatibleServices}
              isWordpress={vm.isWordpress}
              activeProfile={vm.activeProfile}
              isRecommended={vm.recommendedFn}
              onToggle={vm.toggleService}
              renderIcon={renderIcon}
            />
          ) : null}

          {techStack ? (
            <EnvVarsSection
              envVars={vm.envVars}
              envVarsJson={vm.envVarsJson}
              onAdd={vm.addEnvVar}
              onRemove={vm.removeEnvVar}
              onUpdate={vm.updateEnvVar}
            />
          ) : null}

          {state.error ? <p className="text-sm text-destructive">{state.error}</p> : null}
          {state.success ? (
            <p className="text-sm text-green-600">Configuration sauvegardée. Le docker-compose.yml a été régénéré.</p>
          ) : null}
        </CardContent>

        {techStack ? (
          <CardFooter>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Enregistrement…" : "Enregistrer la configuration"}
            </Button>
          </CardFooter>
        ) : null}
      </form>
    </Card>
  );
}