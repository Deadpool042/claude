import {
  ExternalLink,
  Calendar,
  FileText,
  ShieldCheck,
  Euro,
  Layers,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  CATEGORY_LABELS,
  CATEGORY_COLORS,
  MAINTENANCE_LABELS,
  MAINTENANCE_PRICES,
  MODULE_CATALOG,
  type Category,
  type MaintenanceLevel,
} from "@/lib/qualification";
import { formatEur } from "@/lib/qualification-ui";
import Link from "next/link";
import { Button } from "@/components/ui/button";

// ── Types ──────────────────────────────────────────────────────────

interface TabOverviewProps {
  project: {
    slug: string;
    description: string | null;
    domain: string | null;
    port: number | null;
    status: string;
    clientId: string;
    clientName: string;
    category: string | null;
    createdAt: Date;
    updatedAt: Date;
  };
  qualification: {
    modules: string | null;
    maintenanceLevel: string | null;
    estimatedBudget: number | null;
  } | null;
  enabledServiceIds: string[];
}

 const ACCESS_SERVICES = [
  { id: "phpmyadmin", label: "phpMyAdmin", prefix: "pma" },
  { id: "mailpit", label: "Mailpit", prefix: "mail" },
  { id: "adminer", label: "Adminer", prefix: "adminer" },
  // ajoute quand tu veux: { id: "minio", label: "MinIO", prefix: "minio" },
] as const;

// ── Component ──────────────────────────────────────────────────────

export function TabOverview({ project, qualification, enabledServiceIds }: TabOverviewProps) {
  const host = project.domain ?? `${project.slug}.localhost`;

  // Parse modules
  const moduleIds: string[] =
    qualification?.modules ? (JSON.parse(qualification.modules) as string[]) : [];
  const activeModules = moduleIds
    .map((id) => MODULE_CATALOG.find((m) => m.id === id))
    .filter((m): m is (typeof MODULE_CATALOG)[number] => m != null);

  const maintenance = qualification?.maintenanceLevel as MaintenanceLevel | null;
  const budget = qualification?.estimatedBudget;

  const enabledAccessLinks = ACCESS_SERVICES
    .filter((s) => enabledServiceIds.includes(s.id))
    .map((s) => ({
      id: s.id,
      label: s.label,
      href: `https://${s.prefix}-${project.slug}.localhost`,
    }));
 

  return (
    <div className="space-y-6">
      {/* ── Description ────────────────────────────── */}
      {project.description ? (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <FileText className="size-4 text-muted-foreground" />
              Description
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="whitespace-pre-wrap text-sm text-muted-foreground">
              {project.description}
            </p>
          </CardContent>
        </Card>
      ) : null}

      {/* ── KPI Cards ──────────────────────────────── */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* Budget */}
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <Euro className="size-3.5" />
              Budget estimé
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">
              {budget != null ? formatEur(budget) : "—"}
            </p>
          </CardContent>
        </Card>

        {/* Modules */}
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <Layers className="size-3.5" />
              Modules
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">
              {activeModules.length > 0
                ? String(activeModules.length)
                : "0"}
            </p>
            {activeModules.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {activeModules.slice(0, 4).map((m) => (
                  <Badge key={m.id} variant="outline" className="text-[10px]">
                    {m.name}
                  </Badge>
                ))}
                {activeModules.length > 4 && (
                  <Badge variant="outline" className="text-[10px]">
                    +{String(activeModules.length - 4)}
                  </Badge>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Maintenance */}
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1.5">
              <ShieldCheck className="size-3.5" />
              Maintenance
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-lg font-semibold">
              {maintenance ? MAINTENANCE_LABELS[maintenance] : "—"}
            </p>
            {maintenance && (
              <p className="text-xs text-muted-foreground">
                {MAINTENANCE_PRICES[maintenance]}
              </p>
            )}
          </CardContent>
        </Card>

        {/* Catégorie */}
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Catégorie</CardDescription>
          </CardHeader>
          <CardContent>
            {project.category ? (
              <Badge
                className={`text-sm ${CATEGORY_COLORS[project.category as Category]}`}
              >
                {CATEGORY_LABELS[project.category as Category]}
              </Badge>
            ) : (
              <span className="text-muted-foreground">—</span>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Accès rapide ───────────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Accès</CardTitle>
          <CardDescription>Routing Traefik</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground pb-1">URL</p>
              <Button className="text-sm" variant="secondary" size="sm" disabled={!project.domain && project.port == null}>
                <Link href={`https://${host}`} target="_blank" rel="noopener noreferrer">
                  https://{host}
                </Link>
              </Button>
            </div>

            {/* access aux services:  My PHP Admin s'il existe */}
            
            <div>
              <p className="text-xs text-muted-foreground pb-1">Services</p>

              {enabledAccessLinks.length === 0 ? (
                <p className="text-xs text-muted-foreground">Aucun</p>
              ) : (
                <div className="flex flex-wrap items-center gap-2">
                  {enabledAccessLinks.map((l) => (
                    <Button key={l.id} variant="outline" size="sm" asChild>
                      <Link href={l.href} target="_blank" rel="noopener noreferrer">
                        {l.label}
                        <ExternalLink className="ml-2 size-3" />
                      </Link>
                    </Button>
                  ))}
                </div>
              )}
            </div>

            {project.status === "ACTIVE" && project.port !== null ? (
              <Badge variant="default" className="text-xs">
                <ExternalLink className="mr-1 size-3" />
                Routé
              </Badge>
            ) : (
              <Badge variant="outline" className="text-xs">
                Non routé
              </Badge>
            )}
          </div>
          {project.domain ? (
            <div>
              <p className="text-xs text-muted-foreground">
                Domaine personnalisé
              </p>
              <code className="text-sm">{project.domain}</code>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {/* ── Dates ──────────────────────────────────── */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Calendar className="size-4 text-muted-foreground" />
            Historique
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-8">
            <div>
              <p className="text-xs text-muted-foreground">Créé le</p>
              <p className="text-sm">
                {project.createdAt.toLocaleDateString("fr-FR", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Modifié le</p>
              <p className="text-sm">
                {project.updatedAt.toLocaleDateString("fr-FR", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
