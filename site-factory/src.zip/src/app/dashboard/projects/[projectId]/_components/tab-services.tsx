import { resolveDefaultHostingProfile } from "@/lib/projects/buildProjectCreateArgs";
import { ServicesOrchestrator } from "../services/_components/services-orchestrator";
import { WpToolbox } from "../wordpress/_components/wp-toolbox";
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Wrench } from "lucide-react";
import type { DeployTarget } from "@/lib/qualification";

// ── Types ──────────────────────────────────────────────────────────

interface TabServicesProps {
  projectId: string;
  projectSlug: string;
  projectType: string;
  techStack: string | null;
  deployTarget: DeployTarget;
}

// ── Component ──────────────────────────────────────────────────────

export function TabServices({
  projectId,
  projectSlug,
  projectType,
  techStack,
  deployTarget,
}: TabServicesProps) {

  return (
    <div className="space-y-6">
      <ServicesOrchestrator
        projectId={projectId}
        projectSlug={projectSlug}
        techStack={techStack}
        deployTarget={deployTarget}
      />

      {techStack === "WORDPRESS" && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Wrench className="size-4 text-muted-foreground" />
              WordPress Toolbox
            </CardTitle>
            <CardDescription>
              Permaliens, pages, plugins et thèmes WordPress
            </CardDescription>
          </CardHeader>
          <div className="px-6 pb-6">
            <WpToolbox projectId={projectId} projectType={projectType} hostingProfileId={resolveDefaultHostingProfile(deployTarget)} />
          </div>
        </Card>
      )}
    </div>
  );
}
