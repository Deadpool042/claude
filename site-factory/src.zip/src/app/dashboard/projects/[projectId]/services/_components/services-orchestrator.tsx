"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  FileCode,
  Loader2,
  PackagePlus,
  AlertTriangle,
  Wifi,
  WifiOff,
  Wrench,
  Monitor,
  Server,
} from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ServiceCard } from "./service-card";
import { LogsTerminal } from "./logs-terminal";
import { GlobalActions } from "./global-actions";

// ── Types ──────────────────────────────────────────────────────────────

export interface ServiceInfo {
  service: string;
  label: string;
  state: string;
  status: string;
  ports: string[];
  description: string;
  expected: boolean;
}

type ComposeMode = "dev" | "prod-like";

interface ServicesOrchestratorProps {
  projectId: string;
  projectSlug: string;
  techStack: string | null;
  deployTarget: string;
}

// ── Component ──────────────────────────────────────────────────────────

export function ServicesOrchestrator({
  projectId,
  projectSlug: _projectSlug,
  techStack,
  deployTarget: _deployTarget,
}: ServicesOrchestratorProps) {
  const [services, setServices] = useState<ServiceInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeLog, setActiveLog] = useState<string | null>(null);
  const [composeExists, setComposeExists] = useState(true);
  const [sseConnected, setSseConnected] = useState(false);
  const [mode, setMode] = useState<ComposeMode>("dev");

  const isWordpress = techStack === "WORDPRESS";
  const esRef = useRef<EventSource | null>(null);
  const retryRef = useRef(0);

  // ── Initial fetch (for composeExists check) ────────────────────────

  const fetchServices = useCallback(async () => {
    try {
      const res = await fetch(`/api/docker/projects/${projectId}?mode=${mode}`);
      const data = (await res.json()) as { services: ServiceInfo[]; composeExists: boolean };
      setServices(data.services);
      setComposeExists(data.composeExists);
      setError(null);
    } catch {
      setError("Impossible de récupérer l'état des services.");
    } finally {
      setLoading(false);
    }
  }, [projectId, mode]);


  // ── SSE status stream ──────────────────────────────────────────────

  const connectSSE = useCallback(() => {
    if (esRef.current) {
      esRef.current.close();
    }

    const es = new EventSource(`/api/docker/projects/${projectId}/status/stream?mode=${mode}`);
    esRef.current = es;

    es.addEventListener("status", (event: MessageEvent<string>) => {

      try {
        const data = JSON.parse(event.data) as { project: { services: ServiceInfo[] } };

        setServices(data.project.services);
        setSseConnected(true);
        setLoading(false);
        setError(null);
        retryRef.current = 0;
      } catch {
        // Invalid JSON
      }
    });

    es.addEventListener("heartbeat", () => {
      setSseConnected(true);
    });

    es.addEventListener("error", () => {
      setSseConnected(false);
      es.close();
      esRef.current = null;

      // Reconnect with backoff (max 10s)
      const delay = Math.min(1000 * 2 ** retryRef.current, 10_000);
      retryRef.current += 1;
      setTimeout(connectSSE, delay);
    });

    es.onerror = () => {
      if (es.readyState === EventSource.CLOSED) {
        setSseConnected(false);
      }
    };
  }, [projectId, mode]);

  useEffect(() => {
    setLoading(true);
    // First, do a regular fetch to check composeExists
    void fetchServices();
    // Then connect SSE for real-time updates
    connectSSE();

    return () => {
      if (esRef.current) {
        esRef.current.close();
        esRef.current = null;
      }
    };
  }, [fetchServices, connectSSE]);

  // ── Actions ────────────────────────────────────────────────────────

  async function performAction(action: string, service?: string) {
    const key = service ? `${action}-${service}` : `${action}-all`;
    setActionLoading(key);
    setError(null);
    try {
      const res = await fetch(`/api/docker/projects/${projectId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, service }),
      });
      if (!res.ok) {
        const data = (await res.json()) as { error: string };
        setError(data.error);
      }
      // SSE will pick up the new status automatically
    } catch {
      setError("Erreur lors de l'exécution de l'action.");
    } finally {
      setActionLoading(null);
    }
  }
  const runningCount = services.filter((s) => s.state === "running").length;
  const allRunning = services.length > 0 && runningCount === services.length;


  // ── Mode toggle ─────────────────────────────────────────────────────

  const modeToggle = (
    <div className="inline-flex items-center rounded-lg border bg-muted p-0.5 gap-0.5">
      <button
        type="button"
        onClick={() => { setMode("dev"); }}
        className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
          mode === "dev"
            ? "bg-background text-foreground shadow-sm"
            : "text-muted-foreground hover:text-foreground"
        }`}
      >
        <Monitor className="size-3.5" />
        Local
      </button>
      <button
        type="button"
        onClick={() => { setMode("prod-like"); }}
        className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors ${
          mode === "prod-like"
            ? "bg-background text-foreground shadow-sm"
            : "text-muted-foreground hover:text-foreground"
        }`}
      >
        <Server className="size-3.5" />
        Prod-like
      </button>
    </div>
  );

  // ── No compose file ─────────────────────────────────────────────────

  if (!loading && !composeExists) {
    return (
      <Card className="border-dashed border-amber-500/40">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto mb-3 flex size-14 items-center justify-center rounded-full bg-amber-500/10">
            <FileCode className="size-7 text-amber-500" />
          </div>
          <CardTitle className="text-lg">docker-compose.yml introuvable</CardTitle>
          <CardDescription className="max-w-md mx-auto">
            Le fichier de configuration Docker n&apos;existe pas encore pour ce projet.
            Générez-le pour pouvoir démarrer les services.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center gap-3 pt-0">
          {error ? (
            <div className="flex items-center gap-2 text-sm text-destructive">
              <AlertTriangle className="size-4" />
              {error}
            </div>
          ) : null}
          <Button
            onClick={() => { void performAction("generate"); }}
            disabled={actionLoading !== null}
          >
            {actionLoading === "generate-all" ? (
              <Loader2 className="size-4 animate-spin mr-2" />
            ) : (
              <PackagePlus className="size-4 mr-2" />
            )}
            Générer le docker-compose.yml
          </Button>
          <p className="text-xs text-muted-foreground">
            Le fichier sera créé d&apos;après la configuration du projet (stack, base de données, services).
          </p>
        </CardContent>
      </Card>
    );
  }

  // ── Loading ─────────────────────────────────────────────────────────

  if (loading && services.length === 0) {
    return (
      <div className="flex items-center justify-center py-12 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin mr-2" />
        Chargement des services…
      </div>
    );
  }

  // ── Main view ───────────────────────────────────────────────────────

  return (
    <div className="space-y-6">
      {/* ── SSE status + Mode toggle + WP link ─────────────────── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {sseConnected ? (
            <Badge variant="outline" className="gap-1.5 text-xs text-emerald-600">
              <Wifi className="size-3" />
              Temps réel
            </Badge>
          ) : (
            <Badge variant="outline" className="gap-1.5 text-xs text-muted-foreground">
              <WifiOff className="size-3" />
              Reconnexion…
            </Badge>
          )}
          {modeToggle}
        </div>

        {isWordpress ? (
          <Link href={`/dashboard/projects/${projectId}/wordpress`}>
            <Button variant="outline" size="sm" className="gap-1.5">
              <Wrench className="size-3.5" />
              WordPress Toolbox
            </Button>
          </Link>
        ) : null}
      </div>

      {/* ── Global actions bar ────────────────────────────────── */}
      <GlobalActions
        services={services}
        loading={loading}
        actionLoading={actionLoading}
        allRunning={allRunning}
        runningCount={runningCount}
        error={error}
        onAction={(action: string) => {
          void performAction(action);
        }}
        onShowLogs={() => {
          setActiveLog(activeLog === "all" ? null : "all");
        }}
        activeLog={activeLog}
      />

      {/* ── Service grid ──────────────────────────────────────── */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {services.map((svc) => (
          <ServiceCard
            key={svc.service}
            service={svc}
            actionLoading={actionLoading}
            onAction={(action: string) => {
              void performAction(action, svc.service);
            }}
            onShowLogs={() => {
              setActiveLog(activeLog === svc.service ? null : svc.service);
            }}
            isLogActive={activeLog === svc.service}
          />
        ))}
      </div>

      {/* ── Logs terminal ─────────────────────────────────────── */}
      {activeLog !== null ? (
        <LogsTerminal
          projectId={projectId}
          service={activeLog === "all" ? undefined : activeLog}
          onClose={() => {
            setActiveLog(null);
          }}
        />
      ) : null}
    </div>
  );
}
