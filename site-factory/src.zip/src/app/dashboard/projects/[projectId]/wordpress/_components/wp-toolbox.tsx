"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import {
  Globe,
  FileText,
  Plug,
  Palette,
  RefreshCw,
  Link2,
  Loader2,
  Sparkles,
  Search,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { WP_PRESET_LIST, type WpPreset } from "@/lib/wp-presets";
import type {
  WpPluginSearchResult,
  WpPluginSearchResponse,
} from "@/app/api/wp-plugins/search/route";

import type { WpInfo, WpToolboxProps, TabId } from "./types";
import { PresetsTab } from "./presets-tab";
import { PermalinksTab } from "./permalinks-tab";
import { PagesTab } from "./pages-tab";
import { PluginsTab } from "./plugins-tab";
import { SearchTab } from "./search-tab";
import { ThemesTab } from "./themes-tab";


// ── Component ──────────────────────────────────────────────────────────

export function WpToolbox({
  projectId,
  projectType,
  hostingProfileId,
  isRunning: isRunningProp,
}: WpToolboxProps) {
  const [info, setInfo] = useState<WpInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [newPageTitle, setNewPageTitle] = useState("");
  const [newPluginSlug, setNewPluginSlug] = useState("");
  const [activeTab, setActiveTab] = useState<TabId>("presets");
  const [presetResult, setPresetResult] = useState<string[] | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<WpPreset | null>(
    () => WP_PRESET_LIST.find((p) => p.type === projectType) ?? null
  );
  const [autoDetectedRunning, setAutoDetectedRunning] = useState<boolean | null>(
    null
  );
  const isRunning = isRunningProp ?? autoDetectedRunning ?? false;

  // Plugin search state
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<WpPluginSearchResult[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchPage, setSearchPage] = useState(1);
  const [searchTotalPages, setSearchTotalPages] = useState(0);
  const [searchTotalResults, setSearchTotalResults] = useState(0);
  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchInfo = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/docker/projects/${projectId}/wp`);
      if (!res.ok) {
        if (res.status === 404) {
          setAutoDetectedRunning(false);
          setInfo(null);
          return;
        }
        throw new Error("Impossible de récupérer les informations WordPress");
      }
      const data = (await res.json()) as WpInfo;
      setInfo(data);
      setAutoDetectedRunning(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue");
      if (isRunningProp === undefined) setAutoDetectedRunning(false);
    } finally {
      setLoading(false);
    }
  }, [projectId, isRunningProp]);

  useEffect(() => {
    if (isRunningProp === false) {
      setInfo(null);
      setLoading(false);
      return;
    }
    void fetchInfo();
  }, [fetchInfo, isRunningProp]);

  // ── Action helper ─────────────

  async function performAction(
    action: string,
    args?: Record<string, string>,
    loadingKey?: string
  ) {
    const key = loadingKey ?? action;
    setActionLoading(key);
    setPresetResult(null);
    try {
      const res = await fetch(`/api/docker/projects/${projectId}/wp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, args }),
      });
      if (!res.ok) {
        const body = (await res.json()) as { error?: string };
        throw new Error(body.error ?? "Erreur");
      }
      if (action === "apply-preset") {
        const body = (await res.json()) as { details?: string[] };
        if (body.details) setPresetResult(body.details);
      }
      await fetchInfo();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur inconnue");
    } finally {
      setActionLoading(null);
    }
  }

  // ── Plugin search ─────────────

  async function searchPlugins(q: string, page: number = 1) {
    if (q.trim().length < 2) {
      setSearchResults([]);
      return;
    }
    setSearchLoading(true);
    try {
      const res = await fetch(
        `/api/wp-plugins/search?q=${encodeURIComponent(q)}&page=${String(page)}`
      );
      if (!res.ok) throw new Error("Erreur de recherche");
      const data = (await res.json()) as WpPluginSearchResponse;
      setSearchResults(data.plugins);
      setSearchPage(data.page);
      setSearchTotalPages(data.totalPages);
      setSearchTotalResults(data.totalResults);
    } catch {
      setSearchResults([]);
    } finally {
      setSearchLoading(false);
    }
  }

  function handleSearchInput(value: string) {
    setSearchQuery(value);
    if (searchTimeout.current) clearTimeout(searchTimeout.current);
    searchTimeout.current = setTimeout(() => {
      void searchPlugins(value, 1);
    }, 400);
  }

  // ── Not running state ─────────

  if (!isRunning && !loading) {
    return (
      <Card className="border-dashed">
        <CardHeader className="text-center py-8">
          <Globe className="size-10 mx-auto text-muted-foreground mb-2" />
          <CardTitle className="text-base">WordPress Toolbox</CardTitle>
          <CardDescription>
            Démarrez le conteneur WordPress pour accéder aux outils de
            configuration.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12 gap-3">
          <Loader2 className="size-5 animate-spin text-muted-foreground" />
          <span className="text-sm text-muted-foreground">
            Chargement des données WordPress…
          </span>
        </CardContent>
      </Card>
    );
  }

  if (error && !info) {
    return (
      <Card className="border-destructive/50">
        <CardContent className="py-6 text-center">
          <p className="text-sm text-destructive mb-3">{error}</p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => void fetchInfo()}
          >
            <RefreshCw className="size-3.5 mr-1.5" /> Réessayer
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (!info) return null;



  // ── Installed plugin slugs for search tab ──
  const installedSlugs = new Set(info.plugins.map((p) => p.name));

  // ── Tabs ──────────────────────

  const tabs: Array<{
    id: TabId;
    label: string;
    icon: typeof Globe;
    count?: number;
  }> = [
    { id: "presets", label: "Presets", icon: Sparkles },
    { id: "permalinks", label: "Permaliens", icon: Link2 },
    { id: "pages", label: "Pages", icon: FileText, count: info.pages.length },
    {
      id: "plugins",
      label: "Plugins",
      icon: Plug,
      count: info.plugins.length,
    },
    { id: "search", label: "Store", icon: Search },
    { id: "themes", label: "Thèmes", icon: Palette },
  ];
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe className="size-5 text-blue-500" />
            <CardTitle className="text-base">WordPress Toolbox</CardTitle>
            {info.siteUrl ? (
              <a
                href={info.siteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-muted-foreground hover:underline"
              >
                {info.siteUrl}
              </a>
            ) : null}
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="size-7"
            onClick={() => void fetchInfo()}
            title="Rafraîchir"
          >
            <RefreshCw className="size-3.5" />
          </Button>
        </div>
      </CardHeader>

      {/* Tab bar */}
      <div className="border-b px-6">
        <div className="flex gap-1 overflow-x-auto">
          {tabs.map(({ id, label, icon: Icon, count }) => (
            <button
              key={id}
              type="button"
              onClick={() => {
                setActiveTab(id);
              }}
              className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium border-b-2 transition-colors -mb-px whitespace-nowrap ${
                activeTab === id
                  ? "border-primary text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground/30"
              }`}
            >
              <Icon className="size-3.5" />
              {label}
              {count !== undefined ? (
                <Badge
                  variant="secondary"
                  className="ml-1 text-[10px] px-1.5 py-0"
                >
                  {String(count)}
                </Badge>
              ) : null}
            </button>
          ))}
        </div>
      </div>

      <CardContent className="pt-4">
        {error ? (
          <div className="text-xs text-destructive mb-3 p-2 bg-destructive/5 rounded">
            {error}
          </div>
        ) : null}

        {/* ── Presets Tab ──────────────────────────── */}
        {activeTab === "presets" ? (
          <PresetsTab
            presetList={WP_PRESET_LIST}
          {...(projectType ? { projectType } : {})}
            selectedPreset={selectedPreset}
            presetResult={presetResult}
            actionLoading={actionLoading}
            onSelectPreset={(p) => {
              setSelectedPreset(p);
              setPresetResult(null);
            }}
            onApplyPreset={(type) =>
              void performAction("apply-preset", { preset: type }, "apply-preset")
            }
            hostingProfileId={hostingProfileId}
          />
        ) : null}

        {/* ── Permalinks Tab ───────────────────────── */}
        {activeTab === "permalinks" ? (
          <PermalinksTab
            currentPermalink={info.permalink}
            actionLoading={actionLoading}
            onSetPermalink={(v) =>
              void performAction(
                "set-permalink",
                { structure: v },
                `permalink-${v}`
              )
            }
          />
        ) : null}

        {/* ── Pages Tab ────────────────────────────── */}
        {activeTab === "pages" ? (
          <PagesTab
            pages={info.pages}
            newPageTitle={newPageTitle}
            actionLoading={actionLoading}
            onSetTitle={setNewPageTitle}
            onCreatePage={(title) => {
              void performAction("create-page", { title }, "create-page");
              setNewPageTitle("");
            }}
            onDeletePage={(id) =>
              void performAction(
                "delete-page",
                { pageId: String(id) },
                `delete-${String(id)}`
              )
            }
          />
        ) : null}

        {/* ── Plugins Tab ──────────────────────────── */}
        {activeTab === "plugins" ? (
          <PluginsTab
            plugins={info.plugins}
            newPluginSlug={newPluginSlug}
            actionLoading={actionLoading}
            onSetSlug={setNewPluginSlug}
            onInstallPlugin={(slug) => {
              void performAction(
                "install-plugin",
                { plugin: slug },
                "install-plugin"
              );
              setNewPluginSlug("");
            }}
            onTogglePlugin={(name, activate) =>
              void performAction(
                "toggle-plugin",
                { plugin: name, activate: activate ? "true" : "false" },
                `toggle-${name}`
              )
            }
            onDeletePlugin={(name) =>
              void performAction(
                "delete-plugin",
                { plugin: name },
                `delete-plugin-${name}`
              )
            }
            onUpdatePlugin={(name) =>
              void performAction(
                "update-plugin",
                { plugin: name },
                `update-${name}`
              )
            }
          />
        ) : null}

        {/* ── Store Search Tab ─────────────────────── */}
        {activeTab === "search" ? (
          <SearchTab
            searchQuery={searchQuery}
            searchResults={searchResults}
            searchLoading={searchLoading}
            searchPage={searchPage}
            searchTotalPages={searchTotalPages}
            searchTotalResults={searchTotalResults}
            installedSlugs={installedSlugs}
            actionLoading={actionLoading}
            onSearchInput={handleSearchInput}
            onPageChange={(p) => void searchPlugins(searchQuery, p)}
            onInstallPlugin={(slug) =>
              void performAction(
                "install-plugin",
                { plugin: slug },
                `install-${slug}`
              )
            }
          />
        ) : null}

        {/* ── Themes Tab ───────────────────────────── */}
        {activeTab === "themes" ? (
          <ThemesTab
            themes={info.themes}
            actionLoading={actionLoading}
            onActivateTheme={(name) =>
              void performAction(
                "activate-theme",
                { theme: name },
                `theme-${name}`
              )
            }
          />
        ) : null}
      </CardContent>
    </Card>
  );
}
