"use client";

import { Check, Loader2, Palette } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { WpTheme } from "./types";

// ── ThemesTab ─────────────────────────────────────────────────────────

export function ThemesTab({
  themes,
  actionLoading,
  onActivateTheme,
}: {
  themes: WpTheme[];
  actionLoading: string | null;
  onActivateTheme: (name: string) => void;
}) {
  return (
    <div className="space-y-1.5">
      {themes.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-4">
          Aucun thème
        </p>
      ) : (
        themes.map((theme) => {
          const isActive = theme.status === "active";
          return (
            <div
              key={theme.name}
              className="flex items-center justify-between p-2.5 rounded-lg border hover:bg-muted/30 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Palette className="size-3.5 text-muted-foreground" />
                <span className="text-sm font-medium">{theme.name}</span>
                <span className="text-xs text-muted-foreground">
                  v{theme.version}
                </span>
                {isActive ? (
                  <Badge className="text-[10px] px-1.5 py-0">Actif</Badge>
                ) : null}
              </div>
              {!isActive ? (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 text-xs gap-1"
                  disabled={actionLoading !== null}
                  onClick={() => {
                    onActivateTheme(theme.name);
                  }}
                >
                  {actionLoading === `theme-${theme.name}` ? (
                    <Loader2 className="size-3 animate-spin" />
                  ) : (
                    <Check className="size-3" />
                  )}
                  Activer
                </Button>
              ) : (
                <Badge variant="outline" className="text-[10px]">
                  <Check className="size-2.5 mr-1" /> En cours
                </Badge>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}
