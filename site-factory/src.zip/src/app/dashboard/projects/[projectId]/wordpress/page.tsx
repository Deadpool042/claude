import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/db";
import { PageLayout } from "@/components/shell/page-layout";
import { BreadcrumbOverride } from "@/components/shell/breadcrumb-context";
import { Button } from "@/components/ui/button";
import { WpToolbox } from "./_components/wp-toolbox";
import { resolveDefaultHostingProfile } from "@/lib/projects/buildProjectCreateArgs";

interface WordPressPageProps {
  params: Promise<{ projectId: string }>;
}

export default async function WordPressPage({ params }: WordPressPageProps) {
  const { projectId } = await params;

  const project = await prisma.project.findUnique({
    where: { id: projectId },
    select: {
      id: true,
      name: true,
      slug: true,
      type: true,
      techStack: true,
      wpConfig: true,
      deployTarget: true,
    },
  });

  if (!project || project.techStack !== "WORDPRESS") {
    notFound();
  }

  return (
    <>
      <BreadcrumbOverride
        segments={{ [projectId]: project.name, wordpress: "WordPress Toolbox" }}
      />
      <PageLayout
        title="WordPress Toolbox"
        description={`${project.name} — Permaliens, pages, plugins, thèmes`}
        toolbar={
          <div className="flex items-center gap-2">
            <Link href={`/dashboard/projects/${projectId}/services`}>
              <Button size="sm" variant="outline">
                <ArrowLeft className="size-4" />
                Services
              </Button>
            </Link>
            <Link href={`/dashboard/projects/${projectId}`}>
              <Button size="sm" variant="ghost">
                Projet
              </Button>
            </Link>
          </div>
        }
      >
       <WpToolbox
          projectId={project.id}
          projectType={project.type}
          hostingProfileId={resolveDefaultHostingProfile(project.deployTarget)}
        />
      </PageLayout>
    </>
  );
}
