// ── WordPress Toolbox — shared types & constants ──────────────────────

import type { HostingProfileId } from "@/lib/hosting-profiles";

export interface WpPage {
  ID: number;
  post_title: string;
  post_status: string;
}

export interface WpPlugin {
  name: string;
  status: string;
  version: string;
  update?: string;
}

export interface WpTheme {
  name: string;
  status: string;
  version: string;
}

export interface WpInfo {
  deployTarget: HostingProfileId 
  permalink: string;
  pages: WpPage[];
  plugins: WpPlugin[];
  themes: WpTheme[];
  siteUrl: string;
}

export interface WpToolboxProps {
  projectId: string;
  projectType?: string;
  isRunning?: boolean;
  hostingProfileId: HostingProfileId ;
}

export type TabId =
  | "presets"
  | "permalinks"
  | "pages"
  | "plugins"
  | "themes"
  | "search";

export const PERMALINK_PRESETS = [
  { label: "Simple", value: "" },
  { label: "Nom de l'article", value: "/%postname%/" },
  { label: "Jour et nom", value: "/%year%/%monthnum%/%day%/%postname%/" },
  { label: "Mois et nom", value: "/%year%/%monthnum%/%postname%/" },
  { label: "Numérique", value: "/archives/%post_id%" },
] as const;

// ── Helpers ──────────────────────────────────────────────────────────

export function formatInstalls(n: number): string {
  if (n >= 1_000_000) return `${String(Math.round(n / 1_000_000))}M+`;
  if (n >= 1_000) return `${String(Math.round(n / 1_000))}k+`;
  return String(n);
}
