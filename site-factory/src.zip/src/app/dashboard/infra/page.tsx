import { Network } from "lucide-react";
import { prisma } from "@/lib/db";
import { PageLayout } from "@/components/shell/page-layout";
import { EmptyState } from "@/components/shell/empty-state";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { RegenerateButton } from "./_components/regenerate-button";
import { ToggleServiceButton } from "./_components/toggle-service-button";
import { TestServiceButton } from "./_components/test-service-button";
import Link from "next/link";

export default async function InfraPage() {
  const traefikUrl =
    process.env.TRAEFIK_DASHBOARD_URL ?? "https://traefik.localhost";

  const activeRoutes = await prisma.project.findMany({
    where: { status: "ACTIVE", runtime: { port: { not: null } } },
    select: {
      id: true,
      slug: true,
      name: true,
      domain: true,
      runtime: { select: { port: true } },
    },
    orderBy: { slug: "asc" },
  });

  return (
    <PageLayout
      title="Infrastructure"
      description="Traefik reverse-proxy et routes actives"
      toolbar={<RegenerateButton />}
    >
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Traefik Dashboard</CardTitle>
            <CardDescription>
              Reverse-proxy global pour tous les projets
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              URL :{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">
                {traefikUrl}
              </code>
              <span className="ml-2 text-xs text-warning">(HTTPS uniquement)</span>
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Entrypoints : <strong>web</strong> (:80),{" "}
              <strong>websecure</strong> (:443)
            </p>
            <div className="mt-3 flex items-center gap-2">
              <ToggleServiceButton service="traefik" />
              <TestServiceButton service="traefik" />
              <Link href={traefikUrl} target="_blank" className="text-sm text-muted-foreground">
                Ouvrir le dashboard
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Whoami (test)</CardTitle>
            <CardDescription>
              Service de test pour vérifier le routage Traefik
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              URL :{" "}
              <code className="rounded bg-muted px-1 py-0.5 text-xs">
                https://whoami.localhost
              </code>
            </p>
            <div className="mt-3 flex items-center gap-2">
              <ToggleServiceButton service="whoami" />
              <TestServiceButton service="whoami" />
              <Link href="https://whoami.localhost" target="_blank" className="text-sm text-muted-foreground">
                Ouvrir le whoami
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Routes actives</CardTitle>
            <CardDescription>
              Projets ACTIVE avec port assigné — routés via dynamic.yml
              (auto-reload)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {activeRoutes.length === 0 ? (
              <EmptyState
                icon={
                  <Network className="size-6 text-muted-foreground" />
                }
                title="Aucune route active"
                description="Créez un projet pour générer automatiquement une route Traefik."
              />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Projet</TableHead>
                    <TableHead>Host</TableHead>
                    <TableHead>Port</TableHead>
                    <TableHead>URL</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeRoutes.map((route) => {
                    const port = route.runtime?.port ?? null;
                    const host = route.domain ?? `${route.slug}.localhost`;
                    // Affiche https si le port est 443 ou si le host est connu pour être en HTTPS
                    const isHttps = port === 443 || host.endsWith(".localhost");
                    return (
                      <TableRow key={route.id}>
                        <TableCell className="font-medium">
                          {route.name}
                        </TableCell>
                        <TableCell>
                          <code className="text-xs">{host}</code>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">
                            {port !== null ? String(port) : "—"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <code className="text-xs">
                            {isHttps ? "https" : "http"}://{host}
                          </code>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </PageLayout>
  );
}
