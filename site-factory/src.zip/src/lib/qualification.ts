/**
 * Moteur de qualification — Flux décisionnel (multi-stack)
 *
 * Implémente les règles de :
 *  - flux-decisionnel.md  (catégorisation + requalification)
 *  - grille-qualification-client.md  (questionnaire)
 *  - repartition-financiere.md  (modèle financier Solo / Sous-traitant)
 *  - modules.md  (catalogue modules)
 *
 * Principe fondamental : Stack ≠ Catégorie.
 * La catégorie est déterminée par la complexité fonctionnelle, pas par le stack.
 * Les modules sont universels mais leur TARIF dépend du stack :
 *  - Sur WordPress, des plugins gratuits/premium couvrent souvent le besoin → prix réf.
 *  - Sur stacks JS (Next.js, Nuxt, Astro), tout est dev custom → surcoût module.
 *
 * Aucune interprétation commerciale ne prime sur ce moteur.
 */

// ── Types ────────────────────────────────────────────────────────────

export type Category = "CAT1" | "CAT2" | "CAT3" | "CAT4";
export type MaintenanceLevel = "STANDARD" | "ADVANCED" | "BUSINESS" | "CUSTOM";

/** Mode de facturation */
export type BillingMode = "SOLO" | "SOUS_TRAITANT";

/** Type fonctionnel du projet (aligné sur Prisma ProjectType) */
export type ProjectType = "BLOG" | "VITRINE" | "ECOM" | "APP";

/** Stack technique (aligné sur Prisma TechStack) */
export type TechStack = "WORDPRESS" | "NEXTJS" | "NUXT" | "ASTRO";

export interface ModuleDef {
  id: string;
  name: string;
  description: string;
  /** Catégorie minimum d'éligibilité (le module ne s'active pas en dessous) */
  minCategory: Category;
  /** Si le module est structurant, il peut requalifier le projet vers cette catégorie */
  requalifiesTo: Category | null;
  /** Prix HT setup (one-shot) — référence WordPress */
  priceSetup: number;
  /** Prix max si fourchette, sinon idem priceSetup */
  priceSetupMax: number | null;
  /**
   * Coefficient prix pour les stacks JS (Next.js, Nuxt, Astro).
   *
   * ×1.0 = même prix que WP (module purement métier, pas de plugin WP existant)
   * ×1.5 = surcoût modéré (un plugin WP existe mais la feature doit être codée en JS)
   * ×2.0 = surcoût fort (plugin WP gratuit complet, tout à coder en JS)
   *
   * S'applique à priceSetup et priceSetupMax. WordPress = toujours ×1.0.
   */
  jsMultiplier: number;
  /** Split prestataire en % pour le setup en mode sous-traitant (60 ou 70) */
  splitPrestataireSetup: number;
  /** Abonnement mensuel (0 si pas d'abonnement) */
  priceMonthly: number;
  /** Split prestataire en % pour le récurrent en mode sous-traitant */
  splitPrestataireMonthly: number;
  /** Ce module est-il structurant ? (peut requalifier) */
  isStructurant: boolean;
  /** Tags pour groupement UI */
  group: "ecommerce" | "contenu" | "technique" | "metier" | "premium";
  /** Icône Lucide */
  icon: string;
  /** Note WP : d'où vient la fonctionnalité côté WordPress (plugin gratuit, payant, natif…) */
  wpNote: string;
  /** Niveaux de setup (si le module propose plusieurs niveaux de complexité) */
  setupTiers?: { id: string; name: string; description: string; priceSetup: number; requalifiesTo?: Category }[];
  /** Formules d'abonnement (si le module propose plusieurs paliers mensuel) */
  subscriptionTiers?: { id: string; name: string; description: string; priceMonthly: number }[];
}

// ── Catalogue de modules ─────────────────────────────────────────────

export const MODULE_CATALOG: ModuleDef[] = [
  // ── E-Commerce ──
  // WP : WooCommerce + WPML / Polylang (gratuit ou ~50€)
  // JS : next-intl / i18n custom + routing localisé → dev complet
  {
    id: "multi-langue",
    name: "Multi-langue",
    description: "Traduction partielle ou complète du site",
    minCategory: "CAT2",
    requalifiesTo: "CAT2",
    priceSetup: 800,
    priceSetupMax: 1500,
    jsMultiplier: 1.8,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "contenu",
    icon: "Languages",
    wpNote: "WPML ou Polylang (gratuit/~50 €)",
  },
  // WP : WooCommerce Currency Switcher (gratuit)
  // JS : API taux de change + logique conversion → dev modéré
  {
    id: "multi-devises",
    name: "Multi-devises",
    description: "Gestion de plusieurs devises sur la boutique",
    minCategory: "CAT2",
    requalifiesTo: "CAT2",
    priceSetup: 500,
    priceSetupMax: null,
    jsMultiplier: 2.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "ecommerce",
    icon: "Coins",
    wpNote: "Currency Switcher WooCommerce (gratuit)",
  },
  // WP : WooCommerce Stripe/Mollie (gratuit)
  // JS : Stripe SDK custom + webhooks + checkout → dev complet
  {
    id: "paiement",
    name: "Paiement",
    description: "Passerelle de paiement avancée (Stripe, Mollie…)",
    minCategory: "CAT2",
    requalifiesTo: null,
    priceSetup: 600,
    priceSetupMax: null,
    jsMultiplier: 2.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "ecommerce",
    icon: "CreditCard",
    wpNote: "WooCommerce Stripe/Mollie (gratuit)",
  },
  // WP : WooCommerce Shipping Zones (natif) + extensions
  // JS : logique zones/poids/API transporteurs → dev complet
  {
    id: "livraison",
    name: "Livraison",
    description: "Règles de livraison avancées (zones, poids, transporteurs)",
    minCategory: "CAT2",
    requalifiesTo: null,
    priceSetup: 500,
    priceSetupMax: null,
    jsMultiplier: 2.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "ecommerce",
    icon: "Truck",
    wpNote: "WooCommerce Shipping (natif)",
  },
  // WP : CartFlows / WooFunnels (gratuit de base)
  // JS : tunnel multi-étapes custom + state machine → dev lourd
  {
    id: "tunnel-vente",
    name: "Tunnel de vente",
    description: "Tunnel de conversion avancé (upsell, cross-sell, checkout custom)",
    minCategory: "CAT2",
    requalifiesTo: "CAT2",
    priceSetup: 800,
    priceSetupMax: null,
    jsMultiplier: 2.5,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "ecommerce",
    icon: "ShoppingCart",
    wpNote: "CartFlows / WooFunnels (gratuit)",
  },
  // WP : WooCommerce Analytics (natif) + MonsterInsights
  // JS : dashboard custom + intégration GA4 API → dev modéré
  {
    id: "analytics-ecommerce",
    name: "Analytics e-commerce",
    description: "Dashboard analytics avancé pour la boutique en ligne",
    minCategory: "CAT2",
    requalifiesTo: null,
    priceSetup: 400,
    priceSetupMax: null,
    jsMultiplier: 2.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "ecommerce",
    icon: "BarChart3",
    wpNote: "WooCommerce Analytics (natif)",
  },
  // WP : WooCommerce My Account (natif) + extensions wishlist/points
  // JS : auth + dashboard client + API → dev complet
  {
    id: "compte-client",
    name: "Comptes clients",
    description: "Espace client avancé (historique, wishlist, points)",
    minCategory: "CAT2",
    requalifiesTo: null,
    priceSetup: 600,
    priceSetupMax: null,
    jsMultiplier: 2.5,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "ecommerce",
    icon: "UserCircle",
    wpNote: "WooCommerce My Account (natif)",
  },

  // ── Contenu / Marketing ──
  // WP : Mailchimp for WP (gratuit) / MC4WP
  // JS : API Mailchimp/Brevo + formulaire custom + double opt-in
  {
    id: "newsletter",
    name: "Newsletter & Email",
    description: "Intégration emailing (Mailchimp, Brevo, Sendinblue…)",
    minCategory: "CAT2",
    requalifiesTo: null,
    priceSetup: 400,
    priceSetupMax: null,
    jsMultiplier: 2.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "contenu",
    icon: "Mail",
    wpNote: "MC4WP / Mailchimp for WP (gratuit)",
  },
  // WP : GTM4WP + MonsterInsights (gratuit)
  // JS : GTM/dataLayer custom + consent mode + server-side events
  {
    id: "marketing-tracking",
    name: "Marketing & Tracking",
    description: "GTM, pixels, tracking avancé (RGPD compliant)",
    minCategory: "CAT2",
    requalifiesTo: "CAT2",
    priceSetup: 500,
    priceSetupMax: 1200,
    jsMultiplier: 2.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "contenu",
    icon: "Target",
    wpNote: "GTM4WP + MonsterInsights (gratuit)",
  },

  // ── Technique ──
  // WP : Yoast/Rank Math (gratuit) = schema.org, sitemap, redirections inclus
  // JS : generateMetadata(), sitemap.xml, structured data, redirections → tout à coder
  {
    id: "seo-avance",
    name: "SEO avancé",
    description: "Optimisation SEO poussée (schema.org, sitemap, redirections)",
    minCategory: "CAT2",
    requalifiesTo: null,
    priceSetup: 400,
    priceSetupMax: null,
    jsMultiplier: 2.5,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "technique",
    icon: "Search",
    wpNote: "Yoast / Rank Math (gratuit)",
  },
  // WP : Wordfence/Sucuri (gratuit) + headers + 2FA
  // JS : middleware auth, rate limiting, CSP headers → dev custom
  {
    id: "securite-renforcee",
    name: "Sécurité renforcée",
    description: "2FA, WAF, audit sécurité, hardening avancé",
    minCategory: "CAT2",
    requalifiesTo: null,
    priceSetup: 400,
    priceSetupMax: null,
    jsMultiplier: 2.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "technique",
    icon: "Shield",
    wpNote: "Wordfence / Sucuri (gratuit)",
  },
  // WP : SearchWP / FacetWP (premium ~100–200 €)
  // JS : Meilisearch/Algolia SDK + UI facets → dev complet
  {
    id: "filtre-recherche",
    name: "Recherche & filtres",
    description: "Faceted search, filtres avancés, Elasticsearch/Meilisearch",
    minCategory: "CAT2",
    requalifiesTo: "CAT2",
    priceSetup: 800,
    priceSetupMax: null,
    jsMultiplier: 2.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "technique",
    icon: "Filter",
    wpNote: "SearchWP / FacetWP (payant ~150 €)",
  },
  // WP : quelques lignes CSS + toggle JS
  // JS : CSS variables + next-themes → effort comparable
  {
    id: "dark-mode",
    name: "Dark mode",
    description: "Thème sombre avec bascule automatique",
    minCategory: "CAT1",
    requalifiesTo: null,
    priceSetup: 300,
    priceSetupMax: null,
    jsMultiplier: 1.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "technique",
    icon: "Moon",
    wpNote: "CSS + JS natif",
  },
  // Audit + corrections manuelles dans les deux cas
  {
    id: "accessibilite",
    name: "Accessibilité renforcée",
    description: "WCAG 2.1 AA, audit accessibilité, corrections",
    minCategory: "CAT1",
    requalifiesTo: null,
    priceSetup: 500,
    priceSetupMax: null,
    jsMultiplier: 1.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: false,
    group: "technique",
    icon: "Accessibility",
    wpNote: "Audit manuel (pas de plugin)",
  },
  // WP : plugins webhooks + Zapier/Make
  // JS : API routes custom + SDK tiers → dev complet
  {
    id: "connecteurs",
    name: "Connecteurs simples",
    description: "Intégration APIs tierces (CRM, ERP, comptabilité…)",
    minCategory: "CAT2",
    requalifiesTo: "CAT2",
    priceSetup: 700,
    priceSetupMax: null,
    jsMultiplier: 1.6,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "technique",
    icon: "Plug",
    wpNote: "Webhooks + Zapier/Make",
  },
  // Intégration API IA (OpenAI, Anthropic) → effort similaire quel que soit le stack
  {
    id: "assistant-ia",
    name: "Assistant IA",
    description: "Chatbot IA, recommandations, génération de contenu",
    minCategory: "CAT2",
    requalifiesTo: "CAT2",
    priceSetup: 1200,
    priceSetupMax: null,
    jsMultiplier: 1.0,
    splitPrestataireSetup: 60,
    priceMonthly: 49,
    splitPrestataireMonthly: 70,
    isStructurant: true,
    group: "technique",
    icon: "Bot",
    wpNote: "Dev custom (API OpenAI/Anthropic)",
    setupTiers: [
      { id: "ia-standard", name: "Standard", description: "Assistant simple : FAQ, orientation, réponses basiques", priceSetup: 1200, requalifiesTo: "CAT2" },
      { id: "ia-avance", name: "Avancé", description: "Logique métier, sources multiples, scénarios validés", priceSetup: 2400, requalifiesTo: "CAT3" },
    ],
    subscriptionTiers: [
      { id: "ia-starter", name: "Starter", description: "FAQ statique, orientation, redirection", priceMonthly: 49 },
      { id: "ia-business", name: "Business", description: "Base enrichie, suggestions produits, CTA contextualisés", priceMonthly: 99 },
      { id: "ia-premium", name: "Premium", description: "Scénarios conversationnels, segmentation, parcours guidés", priceMonthly: 149 },
    ],
  },

  // ── Métier (Cat.3) — dev custom quel que soit le stack ──
  {
    id: "accises-fiscalite",
    name: "Accises & fiscalité",
    description: "Gestion des accises, droits spécifiques, TVA complexe",
    minCategory: "CAT3",
    requalifiesTo: "CAT3",
    priceSetup: 4000,
    priceSetupMax: null,
    jsMultiplier: 1.0,
    splitPrestataireSetup: 70,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "metier",
    icon: "Receipt",
    wpNote: "Dev custom (pas de plugin adapté)",
  },
  {
    id: "tarification-metier",
    name: "Tarification métier",
    description: "Grilles tarifaires complexes, règles métier spécifiques",
    minCategory: "CAT3",
    requalifiesTo: "CAT3",
    priceSetup: 3000,
    priceSetupMax: null,
    jsMultiplier: 1.0,
    splitPrestataireSetup: 70,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "metier",
    icon: "Calculator",
    wpNote: "Dev custom (règles métier)",
  },
  {
    id: "dashboard-personnalise",
    name: "Dashboard personnalisé",
    description: "Tableau de bord métier sur mesure",
    minCategory: "CAT3",
    requalifiesTo: "CAT3",
    priceSetup: 3500,
    priceSetupMax: null,
    jsMultiplier: 1.0,
    splitPrestataireSetup: 70,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "metier",
    icon: "LayoutDashboard",
    wpNote: "Dev custom (pas de plugin)",
  },

  // ── Premium (Cat.4) — exclusif JS ou effort équivalent ──
  {
    id: "performance-avancee",
    name: "Performance avancée",
    description: "CDN, optimisation TTFB, caching multiniveau",
    minCategory: "CAT4",
    requalifiesTo: "CAT4",
    priceSetup: 5000,
    priceSetupMax: null,
    jsMultiplier: 1.0,
    splitPrestataireSetup: 60,
    priceMonthly: 0,
    splitPrestataireMonthly: 0,
    isStructurant: true,
    group: "premium",
    icon: "Gauge",
    wpNote: "WP Rocket + config CDN",
  },
];

// ── Constantes ───────────────────────────────────────────────────────

export const CATEGORY_ORDER: Category[] = ["CAT1", "CAT2", "CAT3", "CAT4"];

export const CATEGORY_LABELS: Record<Category, string> = {
  CAT1: "Cat.1 — Standard",
  CAT2: "Cat.2 — Avancé",
  CAT3: "Cat.3 — Métier",
  CAT4: "Cat.4 — Premium",
};

export const CATEGORY_SHORT: Record<Category, string> = {
  CAT1: "Cat.1",
  CAT2: "Cat.2",
  CAT3: "Cat.3",
  CAT4: "Cat.4",
};

export const CATEGORY_COLORS: Record<Category, string> = {
  CAT1: "text-emerald-600 bg-emerald-50 border-emerald-200 dark:text-emerald-400 dark:bg-emerald-950/30 dark:border-emerald-800",
  CAT2: "text-blue-600 bg-blue-50 border-blue-200 dark:text-blue-400 dark:bg-blue-950/30 dark:border-blue-800",
  CAT3: "text-amber-600 bg-amber-50 border-amber-200 dark:text-amber-400 dark:bg-amber-950/30 dark:border-amber-800",
  CAT4: "text-red-600 bg-red-50 border-red-200 dark:text-red-400 dark:bg-red-950/30 dark:border-red-800",
};

/** Labels pour les types fonctionnels de projet */
export const PROJECT_TYPE_LABELS: Record<ProjectType, string> = {
  BLOG: "Blog",
  VITRINE: "Site vitrine",
  ECOM: "E-commerce",
  APP: "Application",
};

/** Labels pour les stacks techniques */
export const TECH_STACK_LABELS: Record<TechStack, string> = {
  WORDPRESS: "WordPress",
  NEXTJS: "Next.js",
  NUXT: "Nuxt",
  ASTRO: "Astro",
};

/**
 * Catégorie initiale par type fonctionnel (flux décisionnel §2)
 *
 * Règle : la catégorie est déterminée par la complexité fonctionnelle.
 * - Blog / Vitrine simple → Cat.1
 * - E-commerce (même simple, WooCommerce = config lourde) → Cat.2
 * - Application → Cat.3
 * - Cat.4 n'est jamais initiale — elle requiert des modules premium
 */
const INITIAL_CATEGORY: Record<ProjectType, Category> = {
  BLOG: "CAT1",
  VITRINE: "CAT1",
  ECOM: "CAT2",
  APP: "CAT3",
};

/** Maintenance alignée sur la catégorie finale (flux §6) */
export const CATEGORY_MAINTENANCE: Record<Category, MaintenanceLevel> = {
  CAT1: "STANDARD",
  CAT2: "ADVANCED",
  CAT3: "BUSINESS",
  CAT4: "CUSTOM",
};

export const MAINTENANCE_LABELS: Record<MaintenanceLevel, string> = {
  STANDARD: "Standard",
  ADVANCED: "Avancée",
  BUSINESS: "Métier renforcée",
  CUSTOM: "Sur mesure",
};

export const MAINTENANCE_PRICES: Record<MaintenanceLevel, string> = {
  STANDARD: "39–79 €/mois",
  ADVANCED: "99 €/mois",
  BUSINESS: "149 €/mois",
  CUSTOM: "Sur devis",
};

/** Budget de base fixe par catégorie (base WordPress, hors modules, hors mise en production) */
export const CATEGORY_BASE_BUDGET: Record<Category, number> = {
  CAT1: 1800,
  CAT2: 4000,
  CAT3: 7000,
  CAT4: 12000,
};

/**
 * Coefficient de tarification par stack technique (budget de base).
 *
 * WordPress est la référence (×1.0) — thèmes FSE gratuits (Twenty Twenty-Five),
 * plugins gratuits (CF7, Yoast, WooCommerce…). Le gros du travail = configuration.
 *
 * Next.js / Nuxt (×1.7) — tout est dev custom : routing, SEO, auth, formulaires,
 * CMS headless, e-commerce (Medusa/Snipcart). TJM dev React > TJM dev WP.
 * Marché FR 2025-2026 : surcoût constaté ×1.5 à ×2.5 (on prend ×1.7 = médian).
 *
 * Astro (×1.35) — plus simple que Next (SSG-first, islands), mais toujours du
 * dev custom. Moins de complexité SSR/state qu'un framework full-stack.
 *
 * Le coefficient s'applique au budget de base.
 * Les modules ont leur propre jsMultiplier (voir ModuleDef).
 */
export const STACK_MULTIPLIER: Record<TechStack, number> = {
  WORDPRESS: 1.0,
  NEXTJS: 1.7,
  NUXT: 1.7,
  ASTRO: 1.35,
};

/**
 * Surcoût e-commerce non-WP.
 *
 * WooCommerce est une solution e-commerce complète gratuite incluse dans WP.
 * Les stacks JS nécessitent l'intégration d'une solution tierce
 * (Medusa, Snipcart, Stripe custom…) → dev + maintenance + hébergement plus lourds.
 * Ce coefficient se cumule avec le STACK_MULTIPLIER.
 */
export const ECOM_NON_WP_MULTIPLIER = 1.5;

/**
 * Stacks autorisées par type fonctionnel.
 * Application = pas de WordPress (dashboard, SaaS, plateforme ≠ WP).
 */
export const ALLOWED_STACKS: Record<ProjectType, TechStack[]> = {
  BLOG: ["WORDPRESS", "NEXTJS", "NUXT", "ASTRO"],
  VITRINE: ["WORDPRESS", "NEXTJS", "NUXT", "ASTRO"],
  ECOM: ["WORDPRESS", "NEXTJS", "NUXT", "ASTRO"],
  APP: ["NEXTJS", "NUXT", "ASTRO"],
};

// ── Cible de déploiement ─────────────────────────────────────────────

/** Cible de déploiement (aligné sur Prisma) */
export type DeployTarget = "DOCKER" | "VERCEL" | "SHARED_HOSTING";

export const DEPLOY_TARGET_LABELS: Record<DeployTarget, string> = {
  DOCKER: "Docker / VPS",
  VERCEL: "Vercel / Cloud",
  SHARED_HOSTING: "Mutualisé",
};

/**
 * Compatibilité stack ↔ hébergement.
 *
 * - Mutualisé (o2switch, OVH) : PHP + MySQL → WordPress classique uniquement.
 *   Pas de Node.js, pas de SSR, pas de processus persistant.
 *
 * - Vercel / Cloud : Serverless + Edge → Next.js natif, Nuxt (Nitro preset),
 *   Astro (adapter Vercel). Pas de PHP → pas de WordPress.
 *
 * - Docker / VPS : Tout fonctionne — PHP, Node.js, containers.
 *   Le client gère son VPS ou on déploie sur l'infra Docker (Traefik).
 *
 * WordPress headless (WP API + frontend JS) supporte 2 architectures :
 *   1. Split : WP sur mutualisé (PHP) + frontend sur Vercel → le plus économique
 *   2. Unifié : tout sur Docker/VPS → plus de contrôle
 */
export const ALLOWED_DEPLOY_TARGETS: Record<TechStack, DeployTarget[]> = {
  WORDPRESS: ["DOCKER", "SHARED_HOSTING"],
  NEXTJS: ["DOCKER", "VERCEL"],
  NUXT: ["DOCKER", "VERCEL"],
  ASTRO: ["DOCKER", "VERCEL"],
};

/**
 * Résout les cibles de déploiement autorisées en tenant compte du mode headless.
 *
 * WordPress classique : Docker + Mutualisé
 * WordPress headless  : Docker (unifié) + Mutualisé (split : WP mutualisé + frontend Vercel)
 * Stacks JS           : Docker + Vercel
 */
export function getAllowedDeployTargets(techStack: TechStack, wpHeadless: boolean): DeployTarget[] {
  if (techStack === "WORDPRESS" && wpHeadless) {
    // WP headless = WP backend (PHP) + frontend JS (Node.js)
    // - SHARED_HOSTING = split : WP sur mutualisé + frontend sur Vercel
    // - DOCKER = unifié : WP + frontend en containers sur le même VPS
    // Vercel seul impossible (pas de PHP pour WP)
    return ["SHARED_HOSTING", "DOCKER"];
  }
  return ALLOWED_DEPLOY_TARGETS[techStack];
}

/** Inverse : stacks autorisées par cible de déploiement */
export const ALLOWED_STACKS_FOR_DEPLOY: Record<DeployTarget, TechStack[]> = {
  DOCKER: ["WORDPRESS", "NEXTJS", "NUXT", "ASTRO"],
  VERCEL: ["NEXTJS", "NUXT", "ASTRO"],
  SHARED_HOSTING: ["WORDPRESS"],
};

/**
 * Coûts d'hébergement indicatifs par cible (à la charge du client).
 * L'hébergement et le domaine sont la propriété du client.
 */
export const HOSTING_COSTS: Record<DeployTarget, { label: string; range: string }> = {
  DOCKER: { label: "VPS géré", range: "15–50 €/mois" },
  VERCEL: { label: "Vercel / Cloud", range: "0–20 €/mois" },
  SHARED_HOSTING: { label: "Mutualisé (o2switch, OVH…)", range: "3–10 €/mois" },
};

/**
 * Coûts hébergement WP headless (2 services : WP backend + frontend JS).
 * Dépend de l'architecture choisie :
 * - Split : mutualisé (WP) + Vercel (frontend) → économique
 * - Unifié : tout sur Docker/VPS → plus de contrôle
 */
export const HOSTING_COST_WP_HEADLESS: Record<DeployTarget, { label: string; range: string }> = {
  SHARED_HOSTING: {
    label: "Split : mutualisé (WP) + Vercel (frontend)",
    range: "3–30 €/mois",
  },
  DOCKER: {
    label: "Unifié : VPS (WP + frontend)",
    range: "15–50 €/mois",
  },
  VERCEL: {
    label: "—",
    range: "N/A",
  },
};

/**
 * Forfait de mise en production (one-shot) par cible de déploiement.
 *
 * Ce forfait couvre le travail de déploiement initial :
 * - Mutualisé : FTP/cPanel, config DNS, SSL Let's Encrypt → effort minimal
 * - Vercel : config projet, variables env, custom domain, preview branches → quasi auto
 * - Docker / VPS : Dockerfile, docker-compose, Traefik, CI/CD, backups → effort conséquent
 *
 * Pour WP headless, on cumule le coût des 2 services :
 * - Split (mutualisé + Vercel) : setup mutualisé + setup Vercel
 * - Unifié (Docker) : setup Docker unique (tout containerisé)
 */
export const DEPLOY_SETUP_COST: Record<DeployTarget, number> = {
  SHARED_HOSTING: 200,
  VERCEL: 150,
  DOCKER: 500,
};

/** Coût de déploiement WP headless (2 services) */
export const DEPLOY_SETUP_COST_WP_HEADLESS: Record<DeployTarget, { cost: number; label: string }> = {
  SHARED_HOSTING: { cost: 350, label: "Mutualisé (WP) + Vercel (frontend)" },
  DOCKER: { cost: 500, label: "Docker unifié (WP + frontend)" },
  VERCEL: { cost: 0, label: "N/A" },
};

/**
 * Calcule le coefficient total applicable au budget de base.
 * = coefficient stack × surcoût e-com non-WP (si applicable)
 */
export function computeStackMultiplier(projectType: ProjectType, techStack: TechStack): number {
  const base = STACK_MULTIPLIER[techStack];
  const isEcomNonWP = projectType === "ECOM" && techStack !== "WORDPRESS";
  return isEcomNonWP ? base * ECOM_NON_WP_MULTIPLIER : base;
}

/** Sélection de tier pour un module (setup + abonnement) */
export interface ModuleTierSelection {
  setupTierId?: string;
  subTierId?: string;
}

/**
 * Résout le prix setup d'un module selon le stack et les tiers sélectionnés.
 *
 * WordPress = prix catalogue (référence).
 * Stacks JS = prix × jsMultiplier du module (arrondi).
 * Si un setupTier est sélectionné, utilise son priceSetup.
 */
export function resolveModulePrice(
  mod: ModuleDef,
  techStack: TechStack,
  tierSelection?: ModuleTierSelection,
): { setup: number; setupMax: number | null } {
  const isJs = techStack !== "WORDPRESS";
  const mult = isJs ? mod.jsMultiplier : 1;

  let baseSetup = mod.priceSetup;
  if (tierSelection?.setupTierId && mod.setupTiers) {
    const tier = mod.setupTiers.find((t) => t.id === tierSelection.setupTierId);
    if (tier) baseSetup = tier.priceSetup;
  }

  return {
    setup: Math.round(baseSetup * mult),
    setupMax: mod.priceSetupMax != null ? Math.round(mod.priceSetupMax * mult) : null,
  };
}

/**
 * Résout le prix mensuel d'un module en tenant compte du subscriptionTier sélectionné.
 */
export function resolveModuleMonthly(
  mod: ModuleDef,
  tierSelection?: ModuleTierSelection,
): number {
  if (tierSelection?.subTierId && mod.subscriptionTiers) {
    const tier = mod.subscriptionTiers.find((t) => t.id === tierSelection.subTierId);
    if (tier) return tier.priceMonthly;
  }
  return mod.priceMonthly;
}

/**
 * Résout la catégorie de requalification d'un module en tenant compte du setupTier sélectionné.
 */
export function resolveModuleRequalification(
  mod: ModuleDef,
  tierSelection?: ModuleTierSelection,
): Category | null {
  if (tierSelection?.setupTierId && mod.setupTiers) {
    const tier = mod.setupTiers.find((t) => t.id === tierSelection.setupTierId);
    if (tier) return tier.requalifiesTo ?? mod.requalifiesTo;
  }
  return mod.requalifiesTo;
}

/** Label du coefficient total pour affichage UI */
export function getMultiplierLabel(projectType: ProjectType, techStack: TechStack): string {
  const multiplier = computeStackMultiplier(projectType, techStack);
  if (multiplier === 1) return "";
  return `×${multiplier.toFixed(multiplier % 1 === 0 ? 1 : 3).replace(/\.?0+$/, "")}`;
}

export const STACK_MULTIPLIER_LABELS: Record<TechStack, string> = {
  WORDPRESS: "×1.0 (réf.)",
  NEXTJS: "×1.7",
  NUXT: "×1.7",
  ASTRO: "×1.35",
};

/** Split création one-shot en mode sous-traitant (% prestataire / % agence) */
export const SPLIT_SOUS_TRAITANT: Record<Category, { prestataire: number; agence: number }> = {
  CAT1: { prestataire: 70, agence: 30 },
  CAT2: { prestataire: 70, agence: 30 },
  CAT3: { prestataire: 70, agence: 30 },
  CAT4: { prestataire: 60, agence: 40 },
};

export const BILLING_MODE_LABELS: Record<BillingMode, string> = {
  SOLO: "Solo (100 %)",
  SOUS_TRAITANT: "Sous-traitant",
};

export const MODULE_GROUPS: Record<ModuleDef["group"], string> = {
  ecommerce: "E-Commerce",
  contenu: "Contenu & Marketing",
  technique: "Technique",
  metier: "Métier / Réglementé",
  premium: "Premium",
};

// ── Fonctions utilitaires ────────────────────────────────────────────

function categoryIndex(cat: Category): number {
  return CATEGORY_ORDER.indexOf(cat);
}

function maxCategory(a: Category, b: Category): Category {
  return categoryIndex(a) >= categoryIndex(b) ? a : b;
}

// ── Moteur de qualification ──────────────────────────────────────────

export interface QualificationInput {
  projectType: ProjectType;
  techStack: TechStack;
  selectedModuleIds: string[];
  billingMode: BillingMode;
  deployTarget: DeployTarget;
  wpHeadless: boolean;
  /** Sélections de tiers par module (clé = module id) */
  tierSelections?: Record<string, ModuleTierSelection>;
}

export interface QualificationResult {
  /** Catégorie initiale (avant modules) */
  initialCategory: Category;
  /** Catégorie finale (après requalification) */
  finalCategory: Category;
  /** La catégorie a-t-elle changé ? */
  wasRequalified: boolean;
  /** Modules sélectionnés avec détail */
  modules: ModuleDef[];
  /** Modules qui ont provoqué une requalification */
  requalifyingModules: ModuleDef[];
  /** Maintenance alignée */
  maintenance: MaintenanceLevel;
  /** Budget estimé */
  budget: {
    base: number;
    modulesTotal: number;
    deployCost: number;
    monthlyTotal: number;
    grandTotal: number;
  };
  /** Mode de facturation */
  billingMode: BillingMode;
  /** Répartition financière (null en mode Solo) */
  splits: {
    baseSplitPrestataire: number;
    baseSplitAgence: number;
    modulesSplitPrestataire: number;
    modulesSplitAgence: number;
  } | null;
}

/**
 * Qualifie un projet en appliquant le flux décisionnel.
 *
 * Règles appliquées (flux-decisionnel.md) :
 * 1. Le type fonctionnel détermine la catégorie initiale (stack indépendant)
 * 2. Chaque module structurant peut requalifier vers le haut
 * 3. La catégorie finale est la plus élevée atteinte
 * 4. La maintenance est alignée sur la catégorie finale
 * 5. En cas de doute → requalification vers la catégorie supérieure
 */
export function qualifyProject(input: QualificationInput): QualificationResult {
  const initialCategory = INITIAL_CATEGORY[input.projectType];

  // Résoudre les modules sélectionnés
  const modules = input.selectedModuleIds
    .map((id) => MODULE_CATALOG.find((m) => m.id === id))
    .filter((m): m is ModuleDef => m != null);

  // Appliquer les règles de requalification (flux §4)
  let finalCategory = initialCategory;
  const requalifyingModules: ModuleDef[] = [];

  // WP headless = architecture double (WP API + frontend JS) → Cat.3 minimum
  if (input.techStack === "WORDPRESS" && input.wpHeadless) {
    finalCategory = maxCategory(finalCategory, "CAT3");
  }

  for (const mod of modules) {
    if (mod.isStructurant) {
      const tierSel = input.tierSelections?.[mod.id];
      const requalTo = resolveModuleRequalification(mod, tierSel);
      if (requalTo) {
        const newCat = maxCategory(finalCategory, requalTo);
        if (newCat !== finalCategory) {
          requalifyingModules.push(mod);
          finalCategory = newCat;
        }
      }
    }
  }

  const wasRequalified = finalCategory !== initialCategory;

  // Maintenance alignée (flux §6)
  const maintenance = CATEGORY_MAINTENANCE[finalCategory];

  // Budget — appliquer le coefficient stack (+ e-com non-WP si applicable)
  const baseRaw = CATEGORY_BASE_BUDGET[finalCategory];
  const multiplier = computeStackMultiplier(input.projectType, input.techStack);
  const base = Math.round(baseRaw * multiplier);

  // Forfait de mise en production (dépend de la cible + headless)
  const isWpH = input.techStack === "WORDPRESS" && input.wpHeadless;
  const deployCost = isWpH
    ? DEPLOY_SETUP_COST_WP_HEADLESS[input.deployTarget].cost
    : DEPLOY_SETUP_COST[input.deployTarget];

  let modulesTotal = 0;
  let monthlyTotal = 0;

  for (const mod of modules) {
    const tierSel = input.tierSelections?.[mod.id];
    const resolved = resolveModulePrice(mod, input.techStack, tierSel);
    modulesTotal += resolved.setup;
    monthlyTotal += resolveModuleMonthly(mod, tierSel);
  }

  // Splits (uniquement en mode sous-traitant)
  let splits: QualificationResult["splits"] = null;

  if (input.billingMode === "SOUS_TRAITANT") {
    const baseSplit = SPLIT_SOUS_TRAITANT[finalCategory];
    let modulesSplitPrestataire = 0;
    let modulesSplitAgence = 0;

    for (const mod of modules) {
      const tierSel = input.tierSelections?.[mod.id];
      const resolved = resolveModulePrice(mod, input.techStack, tierSel);
      modulesSplitPrestataire += resolved.setup * (mod.splitPrestataireSetup / 100);
      modulesSplitAgence += resolved.setup * ((100 - mod.splitPrestataireSetup) / 100);
    }

    splits = {
      baseSplitPrestataire: baseSplit.prestataire,
      baseSplitAgence: baseSplit.agence,
      modulesSplitPrestataire,
      modulesSplitAgence,
    };
  }

  return {
    initialCategory,
    finalCategory,
    wasRequalified,
    modules,
    requalifyingModules,
    maintenance,
    billingMode: input.billingMode,
    budget: {
      base,
      modulesTotal,
      deployCost,
      monthlyTotal,
      grandTotal: base + modulesTotal + deployCost,
    },
    splits,
  };
}

/**
 * Groupe les modules par catégorie de groupe pour l'affichage.
 */
export function groupModules(modules: ModuleDef[]): Record<string, ModuleDef[]> {
  const groups: Partial<Record<string, ModuleDef[]>> = {};
  for (const mod of modules) {
    const key = mod.group;
    if (!groups[key]) groups[key] = [];
    groups[key].push(mod);
  }
  return groups as Record<string, ModuleDef[]>;
}
