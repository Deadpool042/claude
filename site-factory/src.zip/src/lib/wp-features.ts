// src/lib/wp-features.ts
// ── WP "features" (what we want), not "plugins" (how we do it) ─────────

export type PluginCategory =
  | "securite"
  | "rgpd"
  | "performance"
  | "anti-spam"
  | "seo"
  | "formulaire"
  | "redirections"
  | "email"
  | "ecommerce"
  | "contenu"
  | "analytics"
  | "autre";

export const PLUGIN_CATEGORY_LABELS: Record<PluginCategory, string> = {
  securite: "Sécurité",
  rgpd: "RGPD & Cookies",
  performance: "Performance",
  "anti-spam": "Anti-spam",
  seo: "SEO",
  formulaire: "Formulaires",
  redirections: "Redirections",
  email: "Email",
  ecommerce: "E-commerce",
  contenu: "Contenu",
  analytics: "Analytics",
  autre: "Autre",
};

export const PLUGIN_CATEGORY_EMOJI: Record<PluginCategory, string> = {
  securite: "🔐",
  rgpd: "🍪",
  performance: "⚡",
  "anti-spam": "🛡️",
  seo: "📈",
  formulaire: "📝",
  redirections: "🔀",
  email: "✉️",
  ecommerce: "🛒",
  contenu: "📄",
  analytics: "📊",
  autre: "🔧",
};

// A small, stable set of features your presets can ask for.
export type WpFeature =
  | "security_headers"
  | "waf_security"
  | "cookie_consent"
  | "page_cache"
  | "asset_optimization"
  | "image_optimization"
  | "seo"
  | "forms"
  | "redirects"
  | "smtp"
  | "antispam"
  | "toc"
  | "ecommerce"
  | "payment_stripe"
  | "analytics";