import { resolve } from "node:path";
import { prisma } from "@/lib/db";
import type { DeployTarget } from "@/generated/prisma/client";

const CONFIGS_ROOT = resolve(process.cwd(), "..", "configs");

export type WpProjectRef = {
  dir: string;
  slug: string;
  deployTarget: DeployTarget | null;
};

export async function getWpProjectRef(projectId: string): Promise<WpProjectRef | null> {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    select: {
      slug: true,
      techStack: true,
      deployTarget: true,
      client: { select: { slug: true } },
    },
  });

  if (!project || project.techStack !== "WORDPRESS") return null;

  return {
    dir: resolve(CONFIGS_ROOT, project.client.slug, project.slug),
    slug: project.slug,
    deployTarget: project.deployTarget,
  };
}