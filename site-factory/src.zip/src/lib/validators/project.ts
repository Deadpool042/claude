//src/lib/validators/project.ts
import { z } from "zod";

// ── Enums (alignés Prisma) ────────────────────────────────────────────
export const devModeEnum = z.enum(["DEV_COMFORT", "DEV_PROD_LIKE", "PROD"]);
export const projectTypeEnum = z.enum(["VITRINE", "BLOG", "ECOM", "APP"]);
export const projectStatusEnum = z.enum(["DRAFT", "ACTIVE", "ARCHIVED"]);
export const techStackEnum = z.enum(["WORDPRESS", "NEXTJS", "NUXT", "ASTRO"]);
export const deployTargetEnum = z.enum(["DOCKER", "VERCEL", "SHARED_HOSTING"]);
export const frontendStackEnum = z.enum(["NEXTJS", "NUXT", "ASTRO"]);
export const dbTypeEnum = z.enum(["MARIADB", "POSTGRESQL"]);
export const projectCategoryEnum = z.enum(["CAT1", "CAT2", "CAT3", "CAT4"]);
export const maintenanceLevelEnum = z.enum(["STANDARD", "ADVANCED", "BUSINESS", "CUSTOM"]);


// ── Consts ────────────────────────────────────────────────────────────

/** Port range reserved for project dev servers */
export const PROJECT_PORT_MIN = 3001;
export const PROJECT_PORT_MAX = 3999;

// ── Sub-schemas (alignés tables Prisma) ───────────────────────────────

export const runtimeInputSchema = z
  .object({
    port: z
      .number()
      .int("Le port doit être un entier")
      .min(PROJECT_PORT_MIN, `Le port minimum est ${String(PROJECT_PORT_MIN)}`)
      .max(PROJECT_PORT_MAX, `Le port maximum est ${String(PROJECT_PORT_MAX)}`)
      .nullable()
      .default(null),
    localHost: z.string().nullable().default(null),
  })
  .optional();

export const databaseInputSchema = z
  .object({
    dbType: dbTypeEnum.default("MARIADB"),
    dbVersion: z.string().min(1).default("11"),
    dbName: z.string().nullable().default(null),
    dbUser: z.string().nullable().default(null),
    dbPassword: z.string().nullable().default(null),
  })
  .optional();

export const wpConfigInputSchema = z
  .object({
    phpVersion: z.string().min(1).default("8.3"),
    wpHeadless: z.boolean().default(false),
    frontendStack: frontendStackEnum
  .optional()
  .or(z.literal(""))
  .transform((v) => (v === "" ? undefined : v)),

    wpSiteTitle: z.string().nullable().default(null),
    wpAdminUser: z.string().nullable().default(null),
    wpAdminPassword: z.string().nullable().default(null),
    wpAdminEmail: z.string().nullable().default(null),

    wpPermalinkStructure: z.string().nullable().default("/%postname%/"),
    wpDefaultPages: z.string().nullable().default(null), // JSON text
    wpPlugins: z.string().nullable().default(null), // JSON text
    wpTheme: z.string().nullable().default(null),
  })
  .optional();

export const nextConfigInputSchema = z
  .object({
    nodeVersion: z.string().min(1).default("22"),
    envVarsJson: z.string().nullable().default(null), // JSON text
  })
  .optional();

/**
 * Services optionnels (ProjectService)
 * IMPORTANT: On ne met PAS db-mariadb / db-postgresql ici.
 * La DB vient de ProjectDatabase.
 */
export const enabledServiceIdsSchema = z.array(z.string()).optional();

// ── Create ────────────────────────────────────────────────────────────

export const createProjectSchema = z.object({
  name: z
    .string()
    .min(2, "Le nom doit contenir au moins 2 caractères")
    .max(100, "Le nom ne doit pas dépasser 100 caractères"),
  clientId: z.string().min(1, "Le client est requis"),
  devMode: devModeEnum.default("DEV_COMFORT"),

  type: projectTypeEnum.default("VITRINE"),
  description: z
    .string()
    .max(2000, "La description ne doit pas dépasser 2000 caractères")
    .optional()
    .transform((v) => v?.trim() || undefined),

  domain: z
  .string()
  .nullable()
  .default(null)
  .transform((v) => {
    if (v === null) return null;
    const s = v.trim();
    return s === "" ? null : s;
  }),
  gitRepo: z
    .string()
    .url("URL Git invalide")
    .optional()
    .or(z.literal(""))
    .transform((v) => v?.trim() || undefined),

  techStack: techStackEnum.optional(),
  deployTarget: deployTargetEnum.default("DOCKER"),

  category: projectCategoryEnum
  .optional()
  .or(z.literal(""))
  .transform((v) => (v === "" ? undefined : v)),

  // Sub models
  runtime: runtimeInputSchema,
  database: databaseInputSchema,
  wpConfig: wpConfigInputSchema,
  nextConfig: nextConfigInputSchema,

  // Services optionnels
  enabledServiceIds: enabledServiceIdsSchema,

  // Qualification (1:1)
  qualification: z
    .object({
      modules: z.string().optional(), // JSON text
      maintenanceLevel: maintenanceLevelEnum.optional(),
      estimatedBudget: z.number().int().nonnegative().optional(),
    })
    .optional(),
});

// export type CreateProjectInput = z.infer<typeof createProjectSchema>;

// ── Update ────────────────────────────────────────────────────────────

export const updateProjectSchema = z.object({
  name: z
    .string()
    .min(2, "Le nom doit contenir au moins 2 caractères")
    .max(100, "Le nom ne doit pas dépasser 100 caractères"),
  type: projectTypeEnum,
  status: projectStatusEnum,
  description: z
    .string()
    .max(2000, "La description ne doit pas dépasser 2000 caractères")
    .optional()
    .transform((v) => v?.trim() || undefined),

  domain: z
  .string()
  .nullable()
  .default(null)
  .transform((v) => {
    if (v === null) return null;
    const s = v.trim();
    return s === "" ? null : s;
  }),
  gitRepo: z
    .string()
    .url("URL Git invalide")
    .optional()
    .or(z.literal(""))
    .transform((v) => v?.trim() || undefined),

  techStack: techStackEnum.optional(),
  deployTarget: deployTargetEnum,
  category: projectCategoryEnum
  .optional()
  .or(z.literal(""))
  .transform((v) => (v === "" ? undefined : v)),

  // Sub models (optionnels en update)
  runtime: runtimeInputSchema,
  database: databaseInputSchema,
  wpConfig: wpConfigInputSchema,
  nextConfig: nextConfigInputSchema,
  enabledServiceIds: enabledServiceIdsSchema,

  qualification: z
    .object({
      modules: z.string().optional(),
      maintenanceLevel: maintenanceLevelEnum.optional(),
      estimatedBudget: z.number().int().nonnegative().optional(),
    })
    .optional(),
});

// export type UpdateProjectInput = z.infer<typeof updateProjectSchema>;

// ── Labels ────────────────────────────────────────────────────────────

export const PROJECT_TYPE_LABELS: Record<z.infer<typeof projectTypeEnum>, string> =
  {
    VITRINE: "Vitrine",
    BLOG: "Blog",
    ECOM: "E-commerce",
    APP: "Application",
  };

export const PROJECT_STATUS_LABELS: Record<
  z.infer<typeof projectStatusEnum>,
  string
> = {
  DRAFT: "Brouillon",
  ACTIVE: "Actif",
  ARCHIVED: "Archivé",
};

export const TECH_STACK_LABELS: Record<z.infer<typeof techStackEnum>, string> = {
  WORDPRESS: "WordPress",
  NEXTJS: "Next.js",
  NUXT: "Nuxt",
  ASTRO: "Astro",
};

export const DEPLOY_TARGET_LABELS: Record<
  z.infer<typeof deployTargetEnum>,
  string
> = {
  DOCKER: "Docker (auto-hébergé)",
  VERCEL: "Vercel",
  SHARED_HOSTING: "Hébergement mutualisé",
};

export const FRONTEND_STACK_LABELS: Record<
  z.infer<typeof frontendStackEnum>,
  string
> = {
  NEXTJS: "Next.js",
  NUXT: "Nuxt",
  ASTRO: "Astro",
};

export type CreateProjectInput = z.input<typeof createProjectSchema>;   // ce que tu peux recevoir (avant defaults)
export type CreateProjectData  = z.output<typeof createProjectSchema>;  // ce que tu as APRÈS safeParse (defaults appliqués)

export type UpdateProjectInput = z.input<typeof updateProjectSchema>;
export type UpdateProjectData  = z.output<typeof updateProjectSchema>;

// Bonus unions “propres” (si tu veux)
export type ProjectTypeInput = z.infer<typeof projectTypeEnum>;
export type TechStackInput = z.infer<typeof techStackEnum>;
export type DeployTargetInput = z.infer<typeof deployTargetEnum>;
export type FrontendStackInput = z.infer<typeof frontendStackEnum>;