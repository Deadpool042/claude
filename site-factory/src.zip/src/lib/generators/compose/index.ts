import { chmod, mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

import { TechStack } from "@/generated/prisma/client";

import type { ComposeProjectInput, ComposeMode } from "./types";
import { defaultComposeModeFromDevMode, supportsProdCompose } from "./types";

import { wordpressCompose, wpSetupScript, type WpSetupOptions } from "./compose-wordpress";
import { nextjsCompose } from "./compose-nextjs";
import { genericCompose } from "./compose-generic";

/** Monorepo root configs directory */
const CONFIGS_ROOT = resolve(process.cwd(), "..", "configs");

function fileNameForMode(mode: ComposeMode): string {
  switch (mode) {
    case "dev":
      return "docker-compose.local.yml";
    case "prod-like":
      return "docker-compose.prod-like.yml";
    case "prod":
      return "docker-compose.prod.yml";
  }
}

function renderCompose(input: ComposeProjectInput, mode: ComposeMode): string {
  switch (input.techStack) {
    case TechStack.WORDPRESS:
      return wordpressCompose(input, mode);
    case TechStack.NEXTJS:
      return nextjsCompose(input, mode);
    default:
      return genericCompose(input, mode);
  }
}

function buildGeneratedModes(input: ComposeProjectInput): ComposeMode[] {
  const modes: ComposeMode[] = ["dev", "prod-like"];
  if (supportsProdCompose(input.deployTarget)) modes.push("prod");
  return modes;
}

export async function generateComposeFragment(input: ComposeProjectInput): Promise<string> {
  const dir = resolve(CONFIGS_ROOT, input.clientSlug, input.projectSlug);
  await mkdir(dir, { recursive: true });

  const modes = buildGeneratedModes(input);

  // 1) Génération des fichiers par mode
  for (const mode of modes) {
    const content = renderCompose(input, mode);
    const fileName = fileNameForMode(mode);
    await writeFile(resolve(dir, fileName), content, "utf-8");

    // WP setup script uniquement pour le mode dev (local)
    if (input.techStack === TechStack.WORDPRESS && mode === "dev") {
      const setupOpts: WpSetupOptions = {
        permalink: input.wpConfig?.wpPermalinkStructure ?? "/%postname%/",
      };

      if (input.wpConfig?.wpDefaultPages) {
        try {
          setupOpts.pages = JSON.parse(input.wpConfig.wpDefaultPages) as NonNullable<WpSetupOptions["pages"]>;
        } catch {
          // ignore
        }
      }

      if (input.wpConfig?.wpPlugins) {
        try {
          setupOpts.plugins = JSON.parse(input.wpConfig.wpPlugins) as NonNullable<WpSetupOptions["plugins"]>;
        } catch {
          // ignore
        }
      }

      if (input.wpConfig?.wpTheme) setupOpts.theme = input.wpConfig.wpTheme;

      const scriptPath = resolve(dir, "wp-setup.sh");
      await writeFile(scriptPath, wpSetupScript(setupOpts), "utf-8");
      await chmod(scriptPath, 0o755);
    }
  }

  // 2) docker-compose.yml “actif” selon devMode
  let defaultMode = defaultComposeModeFromDevMode(input.devMode);

  // Si devMode = PROD mais prod compose pas supporté (ex Vercel/shared), fallback prod-like
  if (defaultMode === "prod" && !supportsProdCompose(input.deployTarget)) {
    defaultMode = "prod-like";
  }

  const activeContent = renderCompose(input, defaultMode);
  await writeFile(resolve(dir, "docker-compose.yml"), activeContent, "utf-8");

  return resolve(dir, "docker-compose.yml");
}