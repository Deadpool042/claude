import type { ComposeMode, ComposeProjectInput, DatabaseConfig } from "./types";
import { parseEnvVars } from "./shared/env";
import { composeHeader } from "./shared/header";
import { isServiceEnabledForMode } from "./services/enabled";
import { dbServiceBlock } from "./services/db";
import {
  adminerBlock,
  elasticsearchBlock,
  grafanaBlock,
  mailpitBlock,
  meilisearchBlock,
  memcachedBlock,
  minioBlock,
  phpMyAdminBlock,
  rabbitmqBlock,
  redisBlock,
  varnishBlock,
} from "./services/blocks";

// ── WP-CLI Auto-Install Script ─────────────────────────────────────────

export interface WpSetupOptions {
  permalink?: string | null;
  pages?: Array<{ title: string; slug: string; isFrontPage?: boolean; content?: string }>;
  plugins?: Array<{ slug: string; activate?: boolean }>;
  theme?: string | null;
}

export function wpSetupScript(opts?: WpSetupOptions): string {
  const lines: string[] = [
    "#!/bin/bash",
    "set -euo pipefail",
    "",
    "cd /var/www/html",
    "",
    "# ── Copy WordPress files from bundled tarball ──",
    'if [ ! -e wp-includes/version.php ]; then',
    '  echo "📦 Extracting WordPress files..."',
    "  cp -a /usr/src/wordpress/. /var/www/html/",
    "  chown -R www-data:www-data /var/www/html",
    "fi",
    "",
    "# ── Install WP-CLI if not present ──",
    "if ! command -v wp &> /dev/null; then",
    '  echo "📦 Installing WP-CLI..."',
    "  curl -sSf https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar -o /usr/local/bin/wp",
    "  chmod +x /usr/local/bin/wp",
    "fi",
    "",
    "# ── Create wp-config.php via WP-CLI if not present ──",
    'if [ ! -e wp-config.php ]; then',
    '  echo "⚙️  Creating wp-config.php..."',
    "  wp config create \\",
    '    --dbname="${WORDPRESS_DB_NAME}" \\',
    '    --dbuser="${WORDPRESS_DB_USER}" \\',
    '    --dbpass="${WORDPRESS_DB_PASSWORD}" \\',
    '    --dbhost="${WORDPRESS_DB_HOST}" \\',
    "    --allow-root",
    "  # Inject reverse-proxy HTTPS detection BEFORE wp-settings.php loads",
    "  if ! grep -q 'X-Forwarded-Proto' wp-config.php; then",
    "    MARKER=\"require_once ABSPATH . 'wp-settings.php';\"",
    `    SNIPPET=$'// Reverse-proxy HTTPS detection\\nif (isset(\\$_SERVER[\\'HTTP_X_FORWARDED_PROTO\\']) && \\$_SERVER[\\'HTTP_X_FORWARDED_PROTO\\'] === \\'https\\') {\\n    \\$_SERVER[\\'HTTPS\\'] = \\'on\\';\\n}\\n'`,
    `    awk -v snippet="$SNIPPET" -v marker="$MARKER" '{if (index($0, marker)) print snippet; print}' wp-config.php > wp-config.tmp && mv wp-config.tmp wp-config.php`,
    "  fi",
    "fi",
    "",
    "# ── Wait for database (MariaDB only in this script) ──",
    'echo "⏳ Waiting for database..."',
    "max_tries=30",
    "count=0",
    'until php -r "\\$c = @new mysqli(getenv(\'WORDPRESS_DB_HOST\'), getenv(\'WORDPRESS_DB_USER\'), getenv(\'WORDPRESS_DB_PASSWORD\'), getenv(\'WORDPRESS_DB_NAME\')); if(\\$c->connect_errno) exit(1);" 2>/dev/null; do',
    "  count=$((count + 1))",
    '  if [ "$count" -ge "$max_tries" ]; then',
    '    echo "❌ Database not reachable after $max_tries attempts"',
    "    exit 1",
    "  fi",
    "  sleep 2",
    "done",
    'echo "✅ Database ready"',
    "",
    "# ── Install WordPress if not yet installed ──",
    "if ! wp core is-installed --allow-root 2>/dev/null; then",
    '  echo "🚀 Installing WordPress..."',
    "  wp core install \\",
    '    --url="${WP_URL:-http://localhost}" \\',
    '    --title="${WP_TITLE:-Mon Site}" \\',
    '    --admin_user="${WP_ADMIN_USER:-admin}" \\',
    '    --admin_password="${WP_ADMIN_PASSWORD:-admin}" \\',
    '    --admin_email="${WP_ADMIN_EMAIL:-admin@example.com}" \\',
    "    --skip-email \\",
    "    --allow-root",
    "",
    "  wp language core install fr_FR --allow-root 2>/dev/null || true",
    "  wp site switch-language fr_FR --allow-root 2>/dev/null || true",
    "",
    "  wp post delete 1 --force --allow-root 2>/dev/null || true",
    "  wp post delete 2 --force --allow-root 2>/dev/null || true",
    "",
  ];

  const permalink = opts?.permalink ?? "/%postname%/";
  lines.push(
    "  # Set permalink structure",
    `  wp rewrite structure "${permalink}" --allow-root`,
    "  wp rewrite flush --allow-root",
    "",
  );

  if (opts?.pages?.length) {
    lines.push("  # ── Create preset pages ──");
    let hasFront = false;

    for (const page of opts.pages) {
      const escapedTitle = page.title.replace(/"/g, '\\"');
      const contentArg = page.content
        ? ` --post_content='${page.content.replace(/'/g, "'\\''")}'`
        : "";

      if (page.isFrontPage) {
        hasFront = true;
        lines.push(
          `  FRONT_PAGE_ID=$(wp post create --post_type=page --post_title="${escapedTitle}" --post_name="${page.slug}" --post_status=publish${contentArg} --porcelain --allow-root)`,
        );
      } else {
        lines.push(
          `  wp post create --post_type=page --post_title="${escapedTitle}" --post_name="${page.slug}" --post_status=publish${contentArg} --allow-root`,
        );
      }
    }

    if (hasFront) {
      lines.push(
        "",
        '  wp option update show_on_front "page" --allow-root',
        '  wp option update page_on_front "$FRONT_PAGE_ID" --allow-root',
      );
    }

    lines.push("");
  }

  if (opts?.plugins?.length) {
    lines.push("  # ── Install plugins ──");
    for (const plugin of opts.plugins) {
      const activateFlag = plugin.activate !== false ? " --activate" : "";
      lines.push(
        `  wp plugin install ${plugin.slug}${activateFlag} --allow-root 2>/dev/null || echo "⚠️ Plugin ${plugin.slug} skipped"`,
      );
    }
    lines.push("");
  }

  if (opts?.theme) {
    lines.push(
      "  # ── Install & activate theme ──",
      `  wp theme install ${opts.theme} --activate --allow-root 2>/dev/null || echo "⚠️ Thème ${opts.theme} skipped"`,
      "",
    );
  }

  lines.push(
    '  echo "✅ WordPress installed successfully!"',
    "else",
    '  echo "WordPress is already installed"',
    "fi",
    "",
    "chown -R www-data:www-data /var/www/html/wp-content",
    "find /var/www/html/wp-content -type d -exec chmod 755 {} \\;",
    "find /var/www/html/wp-content -type f -exec chmod 644 {} \\;",
    "",
    "exec apache2-foreground",
    "",
  );

  return lines.join("\n");
}

// ── Headless frontend ─────────────────────────────────────────────────

function frontendImageAndCommand(frontendStack: string, nodeVersion: string): { image: string; command: string } {
  switch (frontendStack) {
    case "NUXT":
      return { image: `node:${nodeVersion}-alpine`, command: "npx nuxi start" };
    case "ASTRO":
      return { image: `node:${nodeVersion}-alpine`, command: "npm start" };
    case "NEXTJS":
    default:
      return { image: `node:${nodeVersion}-alpine`, command: "npm start" };
  }
}

function headlessFrontendBlock(
  slug: string,
  clientSlug: string,
  host: string,
  port: number,
  frontendStack: string,
  nodeVersion: string,
): string[] {
  const { image, command } = frontendImageAndCommand(frontendStack, nodeVersion);
  return [
    `  ${slug}-front:`,
    `    image: ${image}`,
    "    restart: unless-stopped",
    "    working_dir: /app",
    `    command: ${command}`,
    "    environment:",
    `      PORT: "${String(port)}"`,
    '      NODE_ENV: "production"',
    `      WORDPRESS_API_URL: "http://${slug}/wp-json"`,
    `      NEXT_PUBLIC_WORDPRESS_URL: "https://${host}"`,
    "    volumes:",
    `      - ../../../../projects/${clientSlug}/${slug}-front:/app`,
    "    networks:",
    "      - proxy",
    `      - ${slug}_internal`,
    "",
  ];
}

// ── WordPress compose ──────────────────────────────────────────────────

export function wordpressCompose(input: ComposeProjectInput, mode: ComposeMode): string {
  const wp = input.wpConfig;
  const host = input.domain ?? `${input.projectSlug}.localhost`;

  // WP: DB required. If missing in DB table, fallback to MariaDB defaults.
  const db: DatabaseConfig =
    input.database ?? { dbType: "MARIADB", dbVersion: "11", dbName: null, dbUser: null, dbPassword: null };

  const phpVersion = wp?.phpVersion ?? "8.3";
  const dbName = db.dbName ?? `wp_${input.projectSlug.replace(/-/g, "_")}`;
  const dbUser = db.dbUser ?? "wordpress";
  const dbPassword = db.dbPassword ?? "wordpress";

  const enabled = (id: string) =>
    isServiceEnabledForMode(id, input.enabledServiceIds, input.deployTarget, mode);

  const dbBlock = dbServiceBlock(input.projectSlug, { ...db, dbName, dbUser, dbPassword });

  const customEnv = parseEnvVars(input.nextConfig?.envVarsJson ?? null);

  const wpEnv: Record<string, string> = {
    WORDPRESS_DB_HOST: `${input.projectSlug}-db`,
    WORDPRESS_DB_NAME: dbName,
    WORDPRESS_DB_USER: dbUser,
    WORDPRESS_DB_PASSWORD: dbPassword,
    WP_URL: `https://${host}`,
    WP_TITLE: wp?.wpSiteTitle ?? input.projectSlug,
    WP_ADMIN_USER: wp?.wpAdminUser ?? "admin",
    WP_ADMIN_PASSWORD: wp?.wpAdminPassword ?? "admin",
    WP_ADMIN_EMAIL: wp?.wpAdminEmail ?? "admin@example.com",
    ...customEnv,
  };

  if (enabled("redis")) wpEnv.WP_REDIS_HOST = `${input.projectSlug}-redis`;
  if (enabled("memcached")) wpEnv.WP_MEMCACHED_HOST = `${input.projectSlug}-memcached`;
  if (enabled("mailpit")) {
    wpEnv.WORDPRESS_SMTP_HOST = `${input.projectSlug}-mailpit`;
    wpEnv.WORDPRESS_SMTP_PORT = "1025";
  }
  if (enabled("elasticsearch")) wpEnv.ELASTICSEARCH_URL = `http://${input.projectSlug}-elasticsearch:9200`;
  if (enabled("minio")) {
    wpEnv.S3_ENDPOINT = `http://${input.projectSlug}-minio:9000`;
    wpEnv.S3_ACCESS_KEY = "minioadmin";
    wpEnv.S3_SECRET_KEY = "minioadmin";
  }

  const services: string[] = [
    `  ${input.projectSlug}:`,
    `    image: wordpress:php${phpVersion}-apache`,
    "    restart: unless-stopped",
    "    depends_on:",
    `      ${input.projectSlug}-db:`,
    "        condition: service_healthy",
    "    environment:",
    ...Object.entries(wpEnv).map(([k, v]) => `      ${k}: "${v}"`),
    "    volumes:",
    `      - ${input.projectSlug}_wp_data:/var/www/html`,
    "      - ./wp-setup.sh:/usr/local/bin/wp-setup.sh:ro",
    "    networks:",
    "      - proxy",
    `      - ${input.projectSlug}_internal`,
    '    command: ["wp-setup.sh"]',
    "",
    ...dbBlock.service,
  ];

  // Optional services
  if (enabled("phpmyadmin") && db.dbType === "MARIADB") services.push(...phpMyAdminBlock(input.projectSlug, db));
  if (enabled("redis")) services.push(...redisBlock(input.projectSlug));
  if (enabled("mailpit")) services.push(...mailpitBlock(input.projectSlug));
  if (enabled("adminer")) services.push(...adminerBlock(input.projectSlug));
  if (enabled("memcached")) services.push(...memcachedBlock(input.projectSlug));
  if (enabled("elasticsearch")) services.push(...elasticsearchBlock(input.projectSlug));
  if (enabled("meilisearch")) services.push(...meilisearchBlock(input.projectSlug));
  if (enabled("minio")) services.push(...minioBlock(input.projectSlug));
  if (enabled("rabbitmq")) services.push(...rabbitmqBlock(input.projectSlug));
  if (enabled("varnish")) services.push(...varnishBlock(input.projectSlug));
  if (enabled("grafana")) services.push(...grafanaBlock(input.projectSlug));

  // Headless frontend container
  const isHeadless = wp?.wpHeadless === true;
  if (isHeadless) {
    const frontendStack = wp.frontendStack ?? "NEXTJS";
    const nodeVersion = input.nextConfig?.nodeVersion ?? "22";
    services.push(...headlessFrontendBlock(input.projectSlug, input.clientSlug, host, input.port, frontendStack, nodeVersion));
  }

  const allVolumes = [
    `  ${input.projectSlug}_wp_data:`,
    "    driver: local",
    ...dbBlock.volumes,
  ];

  if (enabled("redis")) allVolumes.push(`  ${input.projectSlug}_redis_data:`, "    driver: local");
  if (enabled("elasticsearch")) allVolumes.push(`  ${input.projectSlug}_es_data:`, "    driver: local");
  if (enabled("meilisearch")) allVolumes.push(`  ${input.projectSlug}_meili_data:`, "    driver: local");
  if (enabled("minio")) allVolumes.push(`  ${input.projectSlug}_minio_data:`, "    driver: local");
  if (enabled("rabbitmq")) allVolumes.push(`  ${input.projectSlug}_rabbitmq_data:`, "    driver: local");
  if (enabled("grafana")) allVolumes.push(`  ${input.projectSlug}_grafana_data:`, "    driver: local");

  return [
    composeHeader(input, mode),
    "services:",
    ...services,
    "volumes:",
    ...allVolumes,
    "",
    "networks:",
    "  proxy:",
    "    external: true",
    `  ${input.projectSlug}_internal:`,
    `    name: ${input.projectSlug}_internal`,
    "    driver: bridge",
    "",
  ].join("\n");
}